package com.hpscil.integration.csvcreator.route;

import java.util.Map;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.jackson.ListJacksonDataFormat;
import org.apache.camel.model.dataformat.CsvDataFormat;
import org.apache.camel.spi.DataFormat;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
//import com.hpscil.integration.csvcreator.constants.CsvCreatorConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@ConfigurationProperties(prefix = "csv-creator-route")
@Data
@EqualsAndHashCode(callSuper = true)

public class CsvCreatorRoute extends RouteBuilder {

	private String headerAuditTopic;
	private String preAuditTopic;
	private String brokers;
	private String groupId;
	private String query;
	private String DB_QUERY_RESULT_HEADER = "HCCID,DEFINITION,TYPE\r\n";
	private String obCorrespondenceSftpFolder;
	private String obCorrespondenceSftpArchive;

	@Override
	public void configure() throws Exception {

		// @formatter:off

	//	CsvDataFormat csvFormat = new CsvDataFormat();
	//	csvFormat.setDelimiter(",");
		JacksonDataFormat format = new ListJacksonDataFormat();
		format.useList();
		format.setUnmarshalType(Map.class);
		from("kafka:{{consumer.topic}}?brokers={{kafka.host}}:{{kafka.port}}"
				+ "&maxPollRecords={{consumer.maxPollRecords}}" + "&consumersCount={{consumer.consumersCount}}"
				+ "&seekTo={{consumer.seekTo}}" + "&groupId={{consumer.group}}").routeId("FromKafka")
						// .log("${body}")

						/*
						 * from("kafka:" + headerAuditTopic + "?brokers=" + brokers + "&groupId=" +
						 * groupId) .routeId("csvCreatorRoute") .to("sql:" + query +
						 * "?dataSource=dataSource") .log("STEP 10 - ${body.class.name}")
						 * .log("STEP 20 - ${body}")
						 */
						.log("STEP 30 - ${body}").unmarshal(format).log("STEP 30 - ${body}").marshal().csv() // .setBody(simple(DB_QUERY_RESULT_HEADER
																												// +
																												// "${body}"))
						.log("STEP 40 - ${body}")
						// .to("file:{{OB_OUTPUT}}?fileName=csv.txt&fileExist=Append")
						// .to("sftp://{{sftp.username}}{{OutboundCSVFolderPath}}?password={{sftp.password}}&fileName=${header.fileName}.txt")
						/*
						 * .to("sftp:" + obCorrespondenceSftpFolder +
						 * "?password=password&username=tester&fileName=welcomeletter.csv&readLock=changed&idempotent=true&move="
						 * + obCorrespondenceSftpArchive)
						 */

					//	.to("file:src/main/resources/static?FileName=don1.txt&noop=true").to("stream:out")
						.to("file:D:\\output?FileName=extract-${date:now:dd-MM-yyyy-HHmmss}.txt&fileExist=Append")
						/*
						 * .setHeader("interfaceId", constant(CsvCreatorConstants.INTERFACE_ID))
						 * .setHeader("remarks", constant(CsvCreatorConstants.MOVED_TO_SFTP))
						 */.removeHeaders("kafka*")
						// .to("kafka:preAuditTopic?brokers=" + brokers)
						.log("Done!");

		// @formatter:on

	}

}
