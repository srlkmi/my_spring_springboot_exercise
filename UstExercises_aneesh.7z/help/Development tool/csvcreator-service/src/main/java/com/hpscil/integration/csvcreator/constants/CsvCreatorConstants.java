package com.hpscil.integration.csvcreator.constants;

public class CsvCreatorConstants {
	private CsvCreatorConstants() {

	}

	public static final String INTERFACE_ID = "CORRESPONDENCE_OUTBOUND";
	public static final String FILE_RECEIVED_AUDIT_TYPE = "FILE RECEIVED FROM SFTP";
	public static final String PUSHED_TO_KAFKA_AUDIT_TYPE = "PUSHED TO  INPUT KAFKA TOPIC ";
	public static final String MOVED_TO_SFTP = "MOVED TO SFTP LOCATION";
}