package com.hpscil.integration;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class DatabaseQueryServiceMain {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseQueryServiceMain.class, args);
		CamelContext camelContext = new DefaultCamelContext();
		try {
			camelContext.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
