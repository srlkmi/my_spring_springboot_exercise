package com.hpscil.integration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hpscil.integration.service.InputService;

@RestController
public class InputController {
	@Autowired
	InputService inputService;
	
	@RequestMapping(value = "/getdata", method = RequestMethod.GET)
	public Object getAllAvailableFields(@RequestParam(value = "feednameid", required = true) Integer feedNameId) {
		
		return inputService.getDatabyFeednameId(feedNameId);
		 
	}

}
