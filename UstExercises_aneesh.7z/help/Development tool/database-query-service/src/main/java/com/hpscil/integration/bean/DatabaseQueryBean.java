package com.hpscil.integration.bean;

import org.apache.camel.Exchange;
import org.apache.camel.component.kafka.KafkaConstants;
import org.springframework.stereotype.Component;


@Component
public class DatabaseQueryBean {
	
	public void setAuditHeader(Exchange exchange, String auditType) throws Exception{
		System.out.println("***** Setting Audit type*******"+auditType);
		exchange.getIn().setHeader("interfaceId", "OB_REPRICER");
		exchange.getIn().setHeader("type", auditType);
		exchange.getIn().setHeader(KafkaConstants.TOPIC,"headerAuditTopic4");
		/* exchange.getIn().setHeader("1","feednameid"); */
	}
}