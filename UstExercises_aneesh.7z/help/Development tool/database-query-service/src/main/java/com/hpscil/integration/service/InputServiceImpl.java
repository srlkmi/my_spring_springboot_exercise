package com.hpscil.integration.service;

import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InputServiceImpl implements InputService {
	
	@Autowired
	ProducerTemplate producer;

	@Override
	public Object getDatabyFeednameId(Integer feedNameId) {
		Object[] serviceParams = new Object[] { feedNameId};
		producer.getCamelContext().createProducerTemplate();
		producer.sendBody("direct:start", serviceParams);
		return null;
	}
	
	
	

}
