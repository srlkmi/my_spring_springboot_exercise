package com.hpscil.integration.constants;

public class DatabaseQueryServiceConstants {
	
	
	public static final String AUDIT_TIMER_TRIGGERED = "DATABASE_QUERY_TIMER_TRIGGERED";    
	public static final String AUDIT_QUERY_RESULTS_PUSHED = "QUERY_RESULTS_PUSHED_TO_TOPIC";

}
