package com.hpscil.integration.service;

import org.springframework.stereotype.Service;

@Service
public interface InputService {
	Object getDatabyFeednameId(Integer feedNameId);
}
