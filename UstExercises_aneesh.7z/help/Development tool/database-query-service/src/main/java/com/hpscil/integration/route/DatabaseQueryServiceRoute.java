package com.hpscil.integration.route;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.jackson.ListJacksonDataFormat;
import org.apache.camel.component.kafka.KafkaConstants;
import org.apache.camel.model.dataformat.CsvDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hpscil.integration.constants.DatabaseQueryServiceConstants;
import com.hpscil.integration.strategy.ClaimsAggregationStrategy;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@ConfigurationProperties(prefix = "dbqueryservice-route")
@Data
@EqualsAndHashCode(callSuper = true)

public class DatabaseQueryServiceRoute extends RouteBuilder {

	private String hrdwSelectQuery;
	private String queryResultTopic;
	private String brokers;
	private String cronExpression;
	private String headerAuditTopic;
	private int messageRowSize;
	private String headerAuditTopic3;

	// User defined variables
	String available_fields = "";
	String masterTableName = "";
	Message infield, intable;

	@Override
	public void configure() throws Exception {
		
		from("direct:start")
	    .log("${body}")
	    .process(new Processor() {
			
			@Override
			public void process(Exchange exchange) throws Exception {
				Message feedNameId = exchange.getIn();
				feedNameId.setHeader("feedNameId", exchange.getIn().getBody());
			}
		})
				.toD("sql:SELECT available_fields.field_identifier FROM available_fields join selected_fields where selected_fields.available_field_id=available_fields.id AND selected_fields.feed_name_id = ${in.header.feedNameId} order by selected_fields.order_number asc;?dataSource=#dataSource")
				.process(new Processor() {
					@SuppressWarnings("unchecked")
					@Override
					public void process(Exchange exchange) throws Exception {
						available_fields = getAppendendString((List<Object>) exchange.getIn().getBody());
						Message infield = exchange.getIn();
						infield.setHeader("available_fields", available_fields);
					}
				})

				.toD("sql:SELECT feed_type.feed_table_name FROM feed_type join feed_name  where feed_name.feed_type_id = feed_type.id and feed_name.id = ${in.header.feedNameId}")
				.process(new Processor() {

					@SuppressWarnings("unchecked")
					@Override
					public void process(Exchange exchange) throws Exception {
						masterTableName = getAppendendString((List<Object>) exchange.getIn().getBody());
						Message in = exchange.getIn();
						in.setHeader("masterTableName", masterTableName);
					}
				}).toD("sql:SELECT ${in.header.available_fields}  FROM ${in.header.masterTableName}")
				.log("${body}")
				// .to("sql:SELECT
				// Insurance_Number,Member_First_Name,Member_Middle_Name,Member_Last_Name FROM
				// eligibility" )

				.split(body())
				.log("After split : ${body}")
				.aggregate(constant(true), new
				ClaimsAggregationStrategy()).completionSize(messageRowSize)
				.completionTimeout(100)
		
				.marshal().json(JsonLibrary.Jackson, true).setHeader(KafkaConstants.TOPIC, constant(queryResultTopic))
				.log("${body}")
				// .log("After split: ${body.field_identifier}")
				.to("kafka:" + queryResultTopic + "?brokers=" + brokers)
				.log(LoggingLevel.INFO, "******Query results pushed to topic " + queryResultTopic + " ******")
				// Audit for type- QUERY_RESULTS_PUSHED
				.to("bean:databaseQueryBean?method=setAuditHeader(*,"
                      + DatabaseQueryServiceConstants.AUDIT_QUERY_RESULTS_PUSHED + ")")
				.wireTap("kafka:" + headerAuditTopic3 + "?brokers=" + brokers);
		
		}

	public String get(String feednameid) {
		// Your code would get the `id` value here
		return "" + feednameid;
	}

	public String getAppendendString(List<Object> object) {
		String data = "";
		StringBuffer stringBuffer = new StringBuffer();
		if (object != null && object.size() > 0) {
			for (Object o : object) {
				String str = o.toString();
				str = str.substring(str.indexOf("=") + 1);
				String[] parts = str.split(",");
				for (String part : parts) {
					String st = part.substring(0, part.length() - 1);
					stringBuffer.append(st + ',');
				}
			}
			data = stringBuffer.substring(0, stringBuffer.length() - 1);
		}
		return data;
	}

}
