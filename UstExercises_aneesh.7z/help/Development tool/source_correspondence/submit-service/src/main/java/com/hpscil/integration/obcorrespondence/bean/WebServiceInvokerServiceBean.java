package com.hpscil.integration.obcorrespondence.bean;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Component
public class WebServiceInvokerServiceBean {

	/*
	 * public void getIdsForCorrespondence(Exchange exchange) { ObjectMapper mapper
	 * = new ObjectMapper(); try { List<Correspondence> correspondences =
	 * Arrays.asList(mapper.readValue(exchange.getIn().getBody(String.class),
	 * Correspondence[].class)); for(Correspondence correspondence :
	 * correspondences) { System.out.println(correspondence.getDefinition()); }
	 * exchange.getOut().setBody(correspondences);
	 * 
	 * } catch(IOException e) { e.printStackTrace(); } }
	 */
	
   public void convertJsonToList(Exchange exchange) {
	   Gson gson = new Gson();
	   Type collectionType = new TypeToken<Collection<ObCorrespondence>>(){}.getType();
	   List<ObCorrespondence> correspondenceList = Arrays.asList(gson.fromJson(exchange.getIn().getBody(String.class),ObCorrespondence.class));
			   
	   //new FileReader("D:\\CCOK\\ob_output1\\hccidtype.json")
	   //Collection<ObCorrespondence> correspondenceList =gson.fromJson(exchange.getIn().getBody(String.class), collectionType);
		/*
		 * Iterator<ObCorrespondence> it = correspondenceList.iterator();
		 * while(it.hasNext()) {
		 * 
		 * ObCorrespondence correspondence = it.next();
		 * System.out.println(correspondence); }
		 */
	   exchange.getIn().setBody(correspondenceList);
}
   
   
   
}
