package com.hpscil.integration.obcorrespondence.bean;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Component
public class RecordCounter {

   public void getCount(Exchange exchange) {

	  int count = 0;
	   exchange.getIn().setBody(count);
}
   
   
   
}
