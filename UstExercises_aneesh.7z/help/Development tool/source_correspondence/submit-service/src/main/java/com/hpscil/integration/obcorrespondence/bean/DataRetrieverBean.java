package com.hpscil.integration.obcorrespondence.bean;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
@Component
public class DataRetrieverBean {
	
	/**
	 * This method takes the result of the query and converts in to a json string.
	 * @param dataList containing maps of results
	 * @return json string
	 */
	
	public String convertToJson(List<Map<String, String>> dataList) {		

		String queryResultJson = null;
		if(dataList!=null)
		{
			
		ObjectMapper objectMapper = new ObjectMapper();
				
		try {
			queryResultJson = objectMapper.writeValueAsString(dataList);
			
			System.out.println("QueryResultJson"+queryResultJson);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		}
		return queryResultJson;
	}

}
