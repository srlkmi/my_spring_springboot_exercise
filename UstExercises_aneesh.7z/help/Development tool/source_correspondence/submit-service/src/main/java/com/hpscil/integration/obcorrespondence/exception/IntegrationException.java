package com.hpscil.integration.obcorrespondence.exception;

import org.apache.camel.Exchange;
//import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IntegrationException extends Exception {
	private static final Logger log = LoggerFactory.getLogger(IntegrationException.class);
	private static final long serialVersionUID = 1L;

	public IntegrationException() {

	}

	public IntegrationException(String message) {
		super(message);

	}

	public IntegrationException(Throwable cause) {
		super(cause);

	}

	public IntegrationException(String message, Throwable cause)

	{

		super(message, cause);

	}

	public void handleError(Exchange exchange) {

		Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
		if (null != caused) {
			if (null != caused.getClass()) {
				String localisedrMsg = caused.getClass().toString();
				log.info(
						"***** USTIntegrationException :: handleError :: subscription caused.getClass(): Caught exception in xml elements "
								+ localisedrMsg);
				// exchange.getIn().setHeader("flowException", localisedrMsg);
			}

			if (null != caused.getMessage()) {
				String message = caused.getMessage();
				//if (StringUtils.isNotEmpty(message) && message.length() > 4000) {
				if (!org.apache.cxf.common.util.StringUtils.isEmpty(message) && message.length() > 4000) {
					message = trimMessage(message);
				}
				log.info(
						"***** USTIntegrationException :: handleError :: subscription caused.getMessage(): Caught exception in xml elements "
								+ message);

				// exchange.getIn().setHeader("flowExceptionDetails", message);
			}
		}
	}

	private String trimMessage(String message) {
		// TODO Auto-generated method stub
		return message.trim();
	}
}
