package com.hpscil.integration.obcorrespondence.bean;


import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.hpscil.integration.obcorrespondence.dto.StagingDto;

@Component
public class HeaderSetter {

	@Autowired
	private StagingDto stagingDto;
	public void setStagingHeader(Exchange exchange) {
		Gson gson = new Gson();
		stagingDto.setHccid(getHeader(exchange,"id"));
		System.out.println("StagingDTO"+stagingDto.getHccid());
		String stagingDtoValue = gson.toJson(stagingDto);
		System.out.println("stagingDtoValue::::::::::::::::::::::::::::::::::::::"+stagingDtoValue);
		exchange.getIn().setBody(stagingDtoValue);
	}

	private String getHeader(Exchange exchange, String header) {
		if(exchange.getIn().getHeader(header, String.class)!=null && !exchange.getIn().getHeader(header, String.class).isEmpty()) {
		return exchange.getIn().getHeader(header, String.class);
		}
		else {
			return "";
		}
	}
}
