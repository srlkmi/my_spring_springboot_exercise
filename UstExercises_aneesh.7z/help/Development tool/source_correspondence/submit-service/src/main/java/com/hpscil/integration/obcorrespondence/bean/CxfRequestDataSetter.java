package com.hpscil.integration.obcorrespondence.bean;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.healthedge.Recipient;
import com.healthedge.Subject;
import com.healthedge.SubjectType;

import lombok.Data;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.healthedge.ObjectFactory;
import com.healthedge.ReciepientType;
import com.healthedge.CreateOrUpdateCorrespondence;
import com.healthedge.CorrespondenceStatusTimeChange;
import com.healthedge.CorrespondenceFieldValue;

import org.apache.camel.Body;
import org.apache.camel.Exchange;
import org.apache.camel.Header;
import org.apache.camel.Message;
import org.springframework.stereotype.Component;

@Component
public class CxfRequestDataSetter {

	ObjectFactory objectFactory = new ObjectFactory();

	/*************************************************************************************************
	 * CXFBEAN DATA GENERATOR CLASS TO PASS PARAMETERS TO SOAP UI
	 * @throws JAXBException 
	 * @throws IOException 
	 * @throws JsonProcessingException 
	 *************************************************************************************************/

	//public List<Object> setRequestParametersForCxfBean(@Body Map<?,?> hccIdMap, @Header("requestDefinition") String requestDefinition,@Header("interfaceName") String interfaceName) {
	public void setRequestParametersForCxfBean(Exchange exchange) throws JAXBException, JsonProcessingException, IOException {

		ObCorrespondence correspondence =exchange.getIn().getBody(ObCorrespondence.class);
        	Recipient recipient = createRecipient(correspondence.getHccid());
    		Subject subject = createSubject(correspondence.getHccid());
        	List<Object> parameterListToCallSoapService = new ArrayList<>();
    		parameterListToCallSoapService.add(null);
    		parameterListToCallSoapService.add(null);
    		parameterListToCallSoapService.add(null);
    		parameterListToCallSoapService.add(null);
    		//if(!correspondence.getDefinition().equals("CORRESPONDENCE LETTER1") ) {
    		parameterListToCallSoapService.add(correspondence.getDefinition());
    		//}
    		
    		parameterListToCallSoapService.add(recipient);
    		parameterListToCallSoapService.add(subject);
    		parameterListToCallSoapService.add(null);
    		//exchange.getOut().setBody(parameterListToCallSoapService);
    		exchange.getIn().setBody(parameterListToCallSoapService);
    		
	}
	
	/*
	 * public void setRequestParametersForCxfBean(Exchange exchange) throws
	 * JAXBException, JsonProcessingException, IOException {
	 * CreateOrUpdateCorrespondence createOrUpdateCorrespondence = new
	 * CreateOrUpdateCorrespondence(); Correspondence correspondence
	 * =exchange.getIn().getBody(Correspondence.class); Recipient recipient =
	 * createRecipient(correspondence.getHccid()); Subject subject =
	 * createSubject(correspondence.getHccid()); CorrespondenceStatusTimeChange
	 * correspondenceStatusTimeChange = createCorrespondenceStatusTimeChange();
	 * CorrespondenceFieldValue correspondenceFieldValue =
	 * createCorrespondenceFieldValue();
	 * createOrUpdateCorrespondence.setDescription(null);
	 * createOrUpdateCorrespondence.setId(1234L);
	 * createOrUpdateCorrespondence.getStatusTimeList().add(
	 * correspondenceStatusTimeChange);
	 * createOrUpdateCorrespondence.getManuallyEnteredFields().add(
	 * correspondenceFieldValue);
	 * createOrUpdateCorrespondence.setDefinition(correspondence.getDefinition());
	 * createOrUpdateCorrespondence.setRecipient(recipient);
	 * createOrUpdateCorrespondence.setSubject(subject);
	 * createOrUpdateCorrespondence.setUrl(null);
	 * exchange.getIn().setBody(createOrUpdateCorrespondence); }
	 */
	 
	
	
	/*************************************************************************************************
	 * METHODS TO PASS RECIPIENT AND SUBJECT PARAMETERS TO SOAP UI
	 *************************************************************************************************/

	private Recipient createRecipient(String hccId) {
		Recipient recipient = objectFactory.createRecipient();
		recipient.setHccId(hccId);
		recipient.setRecipientType(ReciepientType.MEMBERSHIP);
		return recipient;
	}

	private Subject createSubject(String hccId) {
		Subject subject = objectFactory.createSubject();
		subject.setHccId(hccId);
		subject.setSubjectType(SubjectType.MEMBERSHIP);
		return subject;
	}
	
	private CorrespondenceStatusTimeChange createCorrespondenceStatusTimeChange() {
		CorrespondenceStatusTimeChange correspondenceStatusTimeChange = objectFactory.createCorrespondenceStatusTimeChange();
		correspondenceStatusTimeChange.setCorrespondenceStatus(null);
		correspondenceStatusTimeChange.setSetOnTime(null);
		return correspondenceStatusTimeChange;
	}
	private CorrespondenceFieldValue createCorrespondenceFieldValue() {
		CorrespondenceFieldValue correspondenceFieldValue = objectFactory.createCorrespondenceFieldValue();
		correspondenceFieldValue.setName(null);
		correspondenceFieldValue.setValue(null);
		return correspondenceFieldValue;
	}
	
	
	private Recipient createRecipientAccount(String groupId) {
        Recipient recipient = objectFactory.createRecipient();
        recipient.setHccId(groupId);
        recipient.setRecipientType(ReciepientType.ACCOUNT);
        return recipient;
    }

    private Subject createSubjectBill(String billNo) {
        Subject subject = objectFactory.createSubject();
        subject.setHccId(billNo);
        subject.setSubjectType(SubjectType.BILL);
        return subject;
    }
   
}
