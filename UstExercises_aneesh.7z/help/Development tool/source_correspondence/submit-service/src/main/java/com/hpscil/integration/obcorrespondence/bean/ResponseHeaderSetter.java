package com.hpscil.integration.obcorrespondence.bean;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.healthedge.ResponseInfo;

@Component
public class ResponseHeaderSetter {
	public void setResponseHeader(Exchange exchange) throws Exception {
		ResponseInfo responseInfo;
		
		if((responseInfo=exchange.getIn().getBody(ResponseInfo.class))!=null) {
			exchange.getIn().setHeader("id", responseInfo.getId());
			/*
			 * exchange.getIn().setHeader("status", responseInfo.getStatus());
			 * if(responseInfo.getStatus().equalsIgnoreCase("SUCCESS")) {
			 * 
			 * }
			 */
			//exchange.getIn().setHeader("id","123");
			System.out.println("RESPONSEINFO"+responseInfo);
		}
	}
}