package com.hpscil.integration.obcorrespondence.bean;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Body;
import org.apache.camel.ExchangeProperty;


import org.springframework.stereotype.Component;

@Component
public class FinalQueryTriggererBodyPreparer {
	
	public Map createMetadataForMessage(@Body Map jsonMessageBodyAsMap, @ExchangeProperty("CamelSplitIndex") int camelSplitIndex, 
			@ExchangeProperty("CamelSplitSize") int camelSplitSize, @ExchangeProperty("CamelSplitComplete") boolean isCamelSplitComplete)
	{
		Map<String, Object> metaDataMap = new HashMap<>();
		metaDataMap.put("camelSplitIndex", camelSplitIndex);
		metaDataMap.put("camelSplitSize", camelSplitSize);
		metaDataMap.put("isCamelSplitComplete", isCamelSplitComplete);
		
		Map<String, Object> bodyMap = new HashMap<>();
		bodyMap.put("metaDataMap", metaDataMap);
		bodyMap.put("payloadMap", jsonMessageBodyAsMap);
		
		return bodyMap;
	}

}
