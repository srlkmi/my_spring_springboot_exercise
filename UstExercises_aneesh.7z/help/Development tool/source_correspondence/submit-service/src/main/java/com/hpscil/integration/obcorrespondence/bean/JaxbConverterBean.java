package com.hpscil.integration.obcorrespondence.bean;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.healthedge.ResponseInfo;

//import com.healthedge.ResponseInfo;

@Component
public class JaxbConverterBean {
	
	public void jaxbConvereter(Exchange exchange) throws Exception {
		
		JAXBElement<ResponseInfo> jaxbElement = new JAXBElement(new QName(ResponseInfo.class.getSimpleName()), ResponseInfo.class,
				exchange.getIn().getBody(ResponseInfo.class));
		exchange.getIn().setBody(jaxbElement);
	}

}