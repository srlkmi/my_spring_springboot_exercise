package com.hpscil.integration.obcorrespondence.config;

import org.apache.camel.component.cxf.CxfEndpoint;
import org.apache.camel.component.cxf.DataFormat;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.healthedge.CorrespondenceServiceStronglyTypedType;

@Configuration
public class CxfEndpointConfig {
	
	/*private String serviceclass;
	 * @Value("${correspondence_functionality.address}") private String address;
	 * 
	 * @Value("${correspondence_functionality.wsdlname}") private String wsdlurl;
	 */ 
	
	
	/**
	 * Define webservice endpoint 
	 * webservice name : CorrespondenceServiceStronglyTyped
	 * operation : createOrUpdateCorrespondence
	 * @return
	 * @throws ClassNotFoundException 
	 */
	
	@Bean (name = "correspondenceEndpoint")
	public CxfEndpoint createCxfEndPoint() throws ClassNotFoundException { 
		//serviceclass="com.healthedge.CorrespondenceServiceStronglyTypedType";
		//String fullAddress = address;
		CxfEndpoint cxfEndpoint = new CxfEndpoint();
		cxfEndpoint.setServiceClass(CorrespondenceServiceStronglyTypedType.class);
		cxfEndpoint.setAddress("http://localhost:8088/mockCorrespondenceServiceStronglyTypedTypePortBinding");
		cxfEndpoint.setWsdlURL("http://localhost:8088/mockCorrespondenceServiceStronglyTypedTypePortBinding?wsdl");
		cxfEndpoint.setDataFormat(DataFormat.POJO);
		//cxfEndpoint.setWsdlURL("http://100.112.29.165:9191/connector/services/classic/CorrespondenceServiceStronglyTyped?wsdl");
		//cxfEndpoint.setAddress("http://100.112.29.165:9191/connector/services/classic/CorrespondenceServiceStronglyTyped");
		cxfEndpoint.setDefaultOperationName("createOrUpdateCorrespondence");
		//cxfEndpoint.setUsername("U28806");
		//cxfEndpoint.setPassword("testHPS001"); 
		return cxfEndpoint;
	}

}