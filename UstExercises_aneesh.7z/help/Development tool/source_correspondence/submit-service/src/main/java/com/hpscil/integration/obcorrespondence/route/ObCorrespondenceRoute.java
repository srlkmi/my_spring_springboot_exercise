package com.hpscil.integration.obcorrespondence.route;

import java.util.Map;

import javax.xml.bind.JAXBContext;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Predicate;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.kafka.KafkaConstants;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.cxf.jaxrs.utils.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthedge.CreateOrUpdateCorrespondence;
import com.healthedge.ResponseInfo;
import com.hpscil.integration.obcorrespondence.bean.ObCorrespondence;
import com.hpscil.integration.obcorrespondence.constants.ObCorrespondenceConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@ConfigurationProperties(prefix = "ob-correspondence-route")
@Data
@EqualsAndHashCode(callSuper = true)
public class ObCorrespondenceRoute extends RouteBuilder {
	private final class LastMessageIfErrorPredicate implements Predicate {
		@Override
		public boolean matches(Exchange exchange) {

			boolean lastMessage = false;
			Map<String, Object> bodyMap = exchange.getIn().getBody(Map.class);
			Map<String, Object> metaDataMap = (Map) bodyMap.get("metaDataMap");
			lastMessage = (Boolean) metaDataMap.get("isCamelSplitComplete");
			return lastMessage;
		}
	}

	private final class ExceptionProcessor implements Processor {
		@Override
		public void process(Exchange exchange) throws Exception {

			Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
			System.out.println("**** Exception: " + exception.getMessage());
			String stacktrace = ExceptionUtils.getStackTrace(exception);
			String jsonBody = exchange.getIn().getBody(String.class);
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> bodyMap = mapper.readValue(jsonBody, Map.class);
			bodyMap.get("metaDataMap");
			bodyMap.put("errorStackTrace", stacktrace);
			bodyMap.put("errorMessage", exception.getMessage());
			String jsonBodyWithError = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(bodyMap);
			exchange.getIn().setBody(jsonBodyWithError);
		}
	}

	private final class LastMessageCheckPredicate implements Predicate {
		@Override
		public boolean matches(Exchange exchange) {
			boolean isLastMessage = false;
			Map<String, Object> metadataMap = exchange.getProperty("metaDataMap", Map.class);
			isLastMessage = (Boolean) metadataMap.get("isCamelSplitComplete");
			return isLastMessage;
		}
	}

	private static final Logger log = LoggerFactory.getLogger(ObCorrespondenceRoute.class);
	private String initialObQueryTopic;
	private String finalObQueryTriggeringTopic;
	private String preAuditTopic;
	private String stagingTopic;
	private String brokers;
	private String groupId;
	private String errorTopic;

	@Override
	public void configure() throws Exception {
		

		JAXBContext jaxbContext = JAXBContext.newInstance(com.healthedge.ObjectFactory.class);
		JaxbDataFormat jaxbUnMarshal = new JaxbDataFormat(jaxbContext);
		jaxbUnMarshal.setContextPath(ResponseInfo.class.getName());
		jaxbUnMarshal.setPartClass(ResponseInfo.class.getName());
		//jaxbUnMarshal.setContextPath(CreateOrUpdateCorrespondence.class.getName());
		//jaxbUnMarshal.setPartClass(CreateOrUpdateCorrespondence.class.getName());

		ObjectMapper jacksonCaseInsensitiveObjectMapper = new ObjectMapper();
		jacksonCaseInsensitiveObjectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		errorHandler(deadLetterChannel("kafka:" + errorTopic + "?brokers=" + brokers)
				.onPrepareFailure(new ExceptionProcessor()).useOriginalMessage());
		
		
		
		// errorHandler(deadLetterChannel("kafka:" + errorTopic + "?brokers=" +
		// brokers).maximumRedeliveries(5).redeliveryDelay(1000));

		/*
		 * onException(Exception.class, JAXBException.class, WSDLException.class,
		 * RuntimeException.class)
		 * .routeId("ENROLL_INBOUND_ROUTER").maximumRedeliveries(2)
		 * .retryAttemptedLogLevel(org.apache.camel.LoggingLevel.WARN).handled(true)
		 * .bean(IntegrationException.class, "handleError");
		 */

		// from("file://{{jsonFolder}}?delay=10s&noop=true")
		from("kafka:" + initialObQueryTopic + "?brokers=" + brokers + "&groupId=" + groupId).startupOrder(1)
			.routeId("outboundCorrespondenceRoute")
			.log(LoggingLevel.INFO, "***** Service 2 Camel headers:${headers}")
			.log(LoggingLevel.INFO, "************************ Service 2 Camel body:${body}")
			.unmarshal()
			.json(JsonLibrary.Jackson).setProperty("metaDataMap", simple("${body[metaDataMap]}"))
			.setBody(simple("${body[payloadMap]}")).marshal().json(JsonLibrary.Jackson)
			.unmarshal(new JacksonDataFormat(jacksonCaseInsensitiveObjectMapper, ObCorrespondence.class))
			
		
			.log(LoggingLevel.INFO,	"Step 30 ************ in route :::  After unmarshal ************* ${body.class.name}|${body}")
			.to("bean:cxfRequestDataSetter?method=setRequestParametersForCxfBean")
			.log(LoggingLevel.INFO, "Step 40 ************ in route :::  before service call ************* ${body}")
			.to("cxf:bean:correspondenceEndpoint")
			.log(LoggingLevel.INFO, "Step 50 ************ in route :::  after service call ************* ${body}")
			.log(LoggingLevel.INFO, "***** Camel headers:${headers}")
			.log(LoggingLevel.INFO, "***** Properties: metaDataMap - ${exchangeProperty.metaDataMap}")

			
			/*.setHeader("interfaceId", constant(ObCorrespondenceConstants.INTERFACE_ID))
			.setHeader("type", constant(ObCorrespondenceConstants.SUBMIT_AUDIT_TYPE))
			.setHeader(KafkaConstants.TOPIC, constant(preAuditTopic)) 
			.wireTap("kafka:" + preAuditTopic + "?brokers=" + brokers) 
			.log(LoggingLevel.INFO, "Step 60 ************ in route :::   *** Pushed to audit queue " +
			preAuditTopic + " for " + ObCorrespondenceConstants.SUBMIT_AUDIT_TYPE)*/
			//Audit table Insert
			  
			// Staging table Insert .to("bean:responseHeaderSetter")
			.log(LoggingLevel.INFO, "************************ body before staging : ${body}")
			.to("bean:headerSetter?method=setStagingHeader")
			.setHeader(KafkaConstants.TOPIC, constant(stagingTopic)) .to("kafka:" +
			stagingTopic + "?brokers=" + brokers) .log(LoggingLevel.INFO,
			"Step 70 ************ in route :::   *** Pushed to staging queue " +
			stagingTopic) // Staging table Insert .end() .end()
			
			
			.choice()
			
				.when(new LastMessageCheckPredicate())
					.setBody(constant("LAST_MESSAGE_PROCESSED"))
					.removeHeaders("kafka*")
					.to("kafka:" + finalObQueryTriggeringTopic + "?brokers=" + brokers)
			.endChoice();

			//Error Handling route!
			from("kafka:" + errorTopic + "?brokers=" + brokers + "&groupId=" + groupId)
				//.log(LoggingLevel.INFO, "***** Properties##############: metaDataMap -
				//${exchangeProperty.EXCEPTION_CAUGHT}")
				//.log("***** Exception Caught: ${exception} *****");
			.log("***** error body: ${body} *****")
				.unmarshal()
				.json(JsonLibrary.Jackson)
				.log("***** error body###################: ${body} *****")
				.choice()
					.when(new LastMessageIfErrorPredicate())
						.log("***** Entered if clause!! *****")
						.setBody(constant("LAST_MESSAGE_PROCESSED"))
						.removeHeaders("kafka*")
						.to("kafka:" + finalObQueryTriggeringTopic + "?brokers=" + brokers)
					.otherwise()
						.log("***** Entered else clause!! *****")
				.endChoice();

		// @formatter:on
	}

}
