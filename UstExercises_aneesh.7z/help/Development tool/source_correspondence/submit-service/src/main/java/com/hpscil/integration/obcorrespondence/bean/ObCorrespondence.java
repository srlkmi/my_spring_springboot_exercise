package com.hpscil.integration.obcorrespondence.bean;

import javax.xml.bind.annotation.XmlAccessType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;*/
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
@JsonIgnoreProperties(ignoreUnknown=true)
//@Data
//@Entity
//@Table(name = "Correspondence")
public class ObCorrespondence implements Serializable {
	//@GeneratedValue(strategy = GenerationType.AUTO)
    
    String definition;
    String hccid;
    String subjecttype;
    String recipienttype;
    String type;
    
	public String getDefinition() {
		return definition;
	}
	public void setDefinition(String definition) {
		this.definition = definition;
	}
	public String getHccid() {
		return hccid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setHccid(String hccid) {
		this.hccid = hccid;
	}
	public String getSubjecttype() {
		return subjecttype;
	}
	public void setSubjecttype(String subjecttype) {
		this.subjecttype = subjecttype;
	}
	public String getRecipienttype() {
		return recipienttype;
	}
	public void setRecipienttype(String recipienttype) {
		this.recipienttype = recipienttype;
	}
	@Override
	public String toString() {
		return "Correspondence [definition=" + definition + ", hccid=" + hccid + ", subjecttype=" + subjecttype
				+ ", recipienttype=" + recipienttype + ", type=" + type + "]";
	}
	
	
	
	
	
    
}
