package com.hpscil.integration.obcorrespondence.dto;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class StagingDto {

	private String hccid;

	public String getHccid() {
		return hccid;
	}

	public void setHccid(String hccid) {
		this.hccid = hccid;
	}
	
}
