package com.hpscil.integration.obcorrespondence.constants;

public class ObCorrespondenceConstants {
	private ObCorrespondenceConstants() {

	}

	public static final String INTERFACE_ID = "CORRESPONDENCE_OUTBOUND";
	public static final String DATA_RECEIVED_AUDIT_TYPE = "DATA RECEIVED FROM SUBMIT SERVICE KAFKA TOPIC";
	public static final String SUBMIT_AUDIT_TYPE = "SUBMITTED CORRESPONDENCE IDS TO HRP";

}