package com.ust.hpsreport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HpsreportApplicationTests {

	@Test
	void contextLoads() {
	}

}
