package com.ust.hpsreport.dto;

public class SelectedFieldsDTO {
	private Integer selectedFieldId;
	private Integer availableFieldId;
	private Integer feedNameId;
	private Integer fieldOrder;
	private String fieldName;
	

	public Integer getSelectedFieldId() {
		return selectedFieldId;
	}

	public void setSelectedFieldId(Integer selectedFieldId) {
		this.selectedFieldId = selectedFieldId;
	}

	public Integer getAvailableFieldId() {
		return availableFieldId;
	}

	public void setAvailableFieldId(Integer availableFieldId) {
		this.availableFieldId = availableFieldId;
	}

	public Integer getFeedNameId() {
		return feedNameId;
	}

	public void setFeedNameId(Integer feedNameId) {
		this.feedNameId = feedNameId;
	}

	public Integer getFieldOrder() {
		return fieldOrder;
	}

	public void setFieldOrder(Integer fieldOrder) {
		this.fieldOrder = fieldOrder;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

}
