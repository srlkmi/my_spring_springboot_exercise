package com.ust.hpsreport.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(schema = "available_fields")
public class AvailableFields implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ID")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer availableFieldId;

	@Column(name = "FIELD_NAME", nullable = false, length = 255)
	private String fieldName;

	@ManyToOne(cascade = CascadeType.ALL, targetEntity = FeedType.class)
	private FeedType feedType;

	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "FIELD_IDENTIFIER")
	private String fieldIdentifier; 
	
	public FeedType getFeedType() {
		return feedType;
	}

	public void setFeedType(FeedType feedType) {
		this.feedType = feedType;
	}

	public String getFieldIdentifier() {
		return fieldIdentifier;
	}

	public void setFieldIdentifier(String fieldIdentifier) {
		this.fieldIdentifier = fieldIdentifier;
	}

	public Integer getAvailableFieldId() {
		return availableFieldId;
	}

	public void setAvailableFieldId(Integer availableFieldId) {
		this.availableFieldId = availableFieldId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
