package com.ust.hpsreport.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(schema = "feed_name")
public class FeedName implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ID")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "FEED_NAME", nullable = false, length = 255)
	private String feedName;

	@Column(name = "FEED_FORMAT", nullable = true, length = 255)
	private String feedFormat;

	@Column(name = "FEED_TYPE_ID", nullable = false)
	private Integer feedTypeId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FEED_TYPE_ID",insertable = false, updatable = false)
	private FeedType feedtype;
	
	@Column(name = "FROM_DATE",nullable = true)
	private Date fromDate;
	
	@Column(name = "TO_DATE",nullable = true)
	private Date toDate;
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Integer getFeedNameId() {
		return id;
	}

	public void setFeedNameId(Integer id) {
		this.id = id;
	}

	public String getFeedName() {
		return feedName;
	}

	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}

	public String getFeedFormat() {
		return feedFormat;
	}

	public void setFeedFormat(String feedFormat) {
		this.feedFormat = feedFormat;
	}

	public int getFeedTypeId() {
		return feedTypeId;
	}

	public void setFeedTypeId(Integer feedTypeId) {
		this.feedTypeId = feedTypeId;
	}

	public FeedType getFeedtype() {
		return feedtype;
	}

	public void setFeedtype(FeedType feedtype) {
		this.feedtype = feedtype;
	}
	
	

}
