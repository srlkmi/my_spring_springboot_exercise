package com.ust.hpsreport.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ust.hpsreport.entity.FeedName;

@Repository
public interface FeedNameRepository extends JpaRepository<FeedName, Integer> {
	
	@Query("SELECT s FROM FeedName s WHERE s.feedTypeId=:feedTypeId")
	List<FeedName> getAllFeedNamesByFeedType(@Param("feedTypeId") Integer feedTypeId);

}
