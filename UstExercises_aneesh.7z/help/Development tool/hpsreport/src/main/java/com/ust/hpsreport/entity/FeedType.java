package com.ust.hpsreport.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "feed_type")
public class FeedType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ID")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer feedTypeId;

	@Column(name = "TYPE_NAME", nullable = false, length = 255)
	private String feedTypeName;

	@Column(name = "FEED_TABLE_NAME", nullable = false, length = 255)
	private String feedTableName;

	public String getFeedTableName() {
		return feedTableName;
	}

	public void setFeedTableName(String feedTableName) {
		this.feedTableName = feedTableName;
	}

	public int getFeedTypeId() {
		return feedTypeId;
	}

	public void setFeedTypeId(Integer feedTypeId) {
		this.feedTypeId = feedTypeId;
	}

	public String getFeedTypeName() {
		return feedTypeName;
	}

	public void setFeedTypeName(String feedTypeName) {
		this.feedTypeName = feedTypeName;
	}

}
