package com.ust.hpsreport.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.hpsreport.dto.FeedDto;
import com.ust.hpsreport.dto.FieldsDto;
import com.ust.hpsreport.dto.RequestDTO;
import com.ust.hpsreport.dto.SelectedFieldsDTO;
import com.ust.hpsreport.entity.AvailableFields;
import com.ust.hpsreport.entity.FeedName;
import com.ust.hpsreport.entity.FeedType;
import com.ust.hpsreport.entity.SelectedFields;
import com.ust.hpsreport.repository.AvailableFieldsRepository;
import com.ust.hpsreport.repository.FeedNameRepository;
import com.ust.hpsreport.repository.FeedTypeRepository;
import com.ust.hpsreport.repository.SelectedFieldsRepository;
import com.ust.hpsreport.service.HpsService;

@Service
@Transactional
public class HpsServiceImpl implements HpsService {

	@Autowired
	FeedTypeRepository feedTypeRepo;
	@Autowired
	AvailableFieldsRepository availableFieldRepo;
	@Autowired
	SelectedFieldsRepository selectedFieldRepo;
	@Autowired
	FeedNameRepository feedNameRepo;

	@Override
	public List<FeedDto> getAllFeedTypes() {

		List<FeedDto> feedDtoList = new ArrayList<FeedDto>();
		List<FeedType> feedTypeList = feedTypeRepo.getAllFeedTypes();
		if (feedTypeList != null) {

			for (FeedType type : feedTypeList) {

				FeedDto feed = new FeedDto();
				feed.setFeedTypeId(type.getFeedTypeId());
				feed.setFeedTypeName(type.getFeedTypeName());
				feedDtoList.add(feed);
			}
		}
		return feedDtoList;
	}
	
	public List<FeedDto> getAllFeedTypess(List<FeedType> feedTypeList) {

		List<FeedDto> feedDtoList = new ArrayList<FeedDto>();
		if (feedTypeList != null) {

			for (FeedType type : feedTypeList) {

				FeedDto feed = new FeedDto();
				feed.setFeedTypeId(type.getFeedTypeId());
				feed.setFeedTypeName(type.getFeedTypeName());
				feedDtoList.add(feed);
				System.out.println(type.getFeedTypeName()+"============>>>");
			}
		}
		return feedDtoList;
	}

	@Override
	public List<FieldsDto> getAvailableFieldsByFeedType(Integer feedTypeId) {

		List<FieldsDto> feildList = new ArrayList<FieldsDto>();
		List<AvailableFields> availableFields = availableFieldRepo.getAvailableFieldsByFeedType(feedTypeId);

		if (availableFields != null) {
			for (AvailableFields fields : availableFields) {
				FieldsDto field = new FieldsDto();
				field.setAvailableFieldId(fields.getAvailableFieldId());
				field.setFieldName(fields.getFieldName());
				field.setDescription(fields.getDescription());
				feildList.add(field);
			}
		}
		return feildList;
	}

	/*
	 * @Override public List<FeedDto> getFeedNameByFeedType(Integer feedTypeId) { //
	 * TODO Auto-generated method stub return null; }
	 */

	@Override
	public RequestDTO setFeedName(RequestDTO requestDTO) {

		FeedName feedNameModel = new FeedName();
		feedNameModel.setFeedNameId(requestDTO.getFeedNameId());
		feedNameModel.setFeedName(requestDTO.getFeedname());
		feedNameModel.setFeedFormat(requestDTO.getFeedFormat());
		feedNameModel.setFeedTypeId(requestDTO.getFeedTypeId());
		feedNameModel.setFromDate(requestDTO.getFromDate());
		feedNameModel.setToDate(requestDTO.getToDate());

		FeedName feedResult = feedNameRepo.save(feedNameModel);

		if (requestDTO.getFeedNameId() != null || requestDTO.getFeedNameId() != 0) {
			List<SelectedFields> selectedDB = selectedFieldRepo.getSelectedFieldsByFeedName(requestDTO.getFeedNameId());
			if (selectedDB != null) {
				for (SelectedFields fields : selectedDB) {
					selectedFieldRepo.delete(fields);
				}
			}
		}
		for (SelectedFieldsDTO selected : requestDTO.getSelectedFields()) {
			SelectedFields selectedModel = new SelectedFields();
			selectedModel.setAvailableFieldId(selected.getAvailableFieldId());
			selectedModel.setFeedNameId(feedResult.getFeedNameId());
			selectedModel.setOrder(selected.getFieldOrder());
			selectedFieldRepo.save(selectedModel);
		}

		return requestDTO;
	}

	@Override
	public List<SelectedFieldsDTO> getSelectedFieldsByFeedName(Integer feedNameId) {

		List<SelectedFieldsDTO> selectedFieldsDTOList = new ArrayList<SelectedFieldsDTO>();
		List<SelectedFields> selectedFields = selectedFieldRepo.getSelectedFieldsByFeedName(feedNameId);
		if (selectedFields != null) {
			for (SelectedFields fields : selectedFields) {
				SelectedFieldsDTO fieldDto = new SelectedFieldsDTO();
				fieldDto.setSelectedFieldId(fields.getSelectedFieldId());
				fieldDto.setFieldName(fields.getAvailableFields().getFieldName());
				fieldDto.setAvailableFieldId(fields.getAvailableFields().getAvailableFieldId());
				fieldDto.setFieldOrder(fields.getOrder());
				selectedFieldsDTOList.add(fieldDto);
			}
		}
		return selectedFieldsDTOList;
	}

	@Override
	public List<FeedDto> getAllFeedNamesByFeedType(Integer feedTypeId) {

		List<FeedDto> feedDtoList = new ArrayList<FeedDto>();
		List<FeedName> feedNameList = feedNameRepo.getAllFeedNamesByFeedType(feedTypeId);
		if (feedNameList != null) {
			for (FeedName feed : feedNameList) {
				FeedDto feedDto = new FeedDto();
				feedDto.setFeedName(feed.getFeedName());
				feedDto.setFeedNameId(feed.getFeedNameId());
				// feedDto.setFeedTypeId(feed.getFeedTypeId());
				feedDto.setFeedFormat(feed.getFeedFormat());
				feedDto.setFeedTypeName(feed.getFeedtype().getFeedTypeName());
				feedDtoList.add(feedDto);
			}
		}
		return feedDtoList;
	}

}
