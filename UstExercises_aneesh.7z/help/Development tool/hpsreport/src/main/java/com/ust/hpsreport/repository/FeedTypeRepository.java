package com.ust.hpsreport.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ust.hpsreport.entity.FeedType;
@Repository
public interface FeedTypeRepository extends JpaRepository<FeedType, Integer> {

	@Query("SELECT f from FeedType f")
	List<FeedType> getAllFeedTypes();
}
