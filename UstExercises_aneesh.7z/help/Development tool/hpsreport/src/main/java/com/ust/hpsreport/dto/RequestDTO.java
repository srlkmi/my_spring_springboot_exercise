package com.ust.hpsreport.dto;

import java.util.Date;

public class RequestDTO {

	private Integer feedTypeId;
	private Integer feedNameId;
	private String feedname;

	private SelectedFieldsDTO[] selectedFields;
	private String feedFormat;

	private Date fromDate;
	private Date toDate;

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Integer getFeedTypeId() {
		return feedTypeId;
	}

	public void setFeedTypeId(Integer feedTypeId) {
		this.feedTypeId = feedTypeId;
	}

	public String getFeedname() {
		return feedname;
	}

	public void setFeedname(String feedname) {
		this.feedname = feedname;
	}

	public SelectedFieldsDTO[] getSelectedFields() {
		return selectedFields;
	}

	public void setSelectedFields(SelectedFieldsDTO[] selectedFields) {
		this.selectedFields = selectedFields;
	}

	public String getFeedFormat() {
		return feedFormat;
	}

	public void setFeedFormat(String feedFormat) {
		this.feedFormat = feedFormat;
	}

	public Integer getFeedNameId() {
		return feedNameId;
	}

	public void setFeedNameId(Integer feedNameId) {
		this.feedNameId = feedNameId;
	}

}
