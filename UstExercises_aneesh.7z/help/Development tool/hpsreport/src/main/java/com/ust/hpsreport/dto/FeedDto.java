package com.ust.hpsreport.dto;

public class FeedDto {

	private int feedTypeId;
	private String feedTypeName;
	private int feedNameId;
	private String feedName;
	private String feedFormat;

	public int getFeedTypeId() {
		return feedTypeId;
	}

	public void setFeedTypeId(int feedTypeId) {
		this.feedTypeId = feedTypeId;
	}

	public String getFeedTypeName() {
		return feedTypeName;
	}

	public void setFeedTypeName(String feedTypeName) {
		this.feedTypeName = feedTypeName;
	}

	public int getFeedNameId() {
		return feedNameId;
	}

	public void setFeedNameId(int feedNameId) {
		this.feedNameId = feedNameId;
	}

	public String getFeedName() {
		return feedName;
	}

	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}

	public String getFeedFormat() {
		return feedFormat;
	}

	public void setFeedFormat(String feedFormat) {
		this.feedFormat = feedFormat;
	}

}
