package com.ust.hpsreport.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ust.hpsreport.dto.FeedDto;
import com.ust.hpsreport.dto.FieldsDto;
import com.ust.hpsreport.dto.RequestDTO;
import com.ust.hpsreport.dto.SelectedFieldsDTO;

@Component
@Transactional
public interface HpsService {

	List<FeedDto> getAllFeedTypes();

	List<FieldsDto> getAvailableFieldsByFeedType(Integer feedTypeId);

//	List<FeedDto> getFeedNameByFeedType(Integer feedTypeId);
	
	List<SelectedFieldsDTO> getSelectedFieldsByFeedName(Integer feedNameId);

	RequestDTO setFeedName(RequestDTO requestDTO);

	List<FeedDto> getAllFeedNamesByFeedType(Integer feedTypeId);

}

