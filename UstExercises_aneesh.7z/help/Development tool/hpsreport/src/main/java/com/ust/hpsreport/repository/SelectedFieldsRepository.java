package com.ust.hpsreport.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ust.hpsreport.entity.SelectedFields;

@Repository
public interface SelectedFieldsRepository extends JpaRepository<SelectedFields, Integer> {

	@Query("SELECT s FROM SelectedFields s WHERE s.feedNameId=?1")
	List<SelectedFields> getSelectedFieldByFeedId(Integer feedId);

	@Query("SELECT s FROM SelectedFields s WHERE s.feedNameId=:feedNameId")
	List<SelectedFields> getSelectedFieldsByFeedName(@Param("feedNameId") Integer feedNameId);

	@Query("UPDATE  SelectedFields s SET s.isObsolete=1 WHERE s.feedNameId=?1")
	void updateSelectedFieldById(Integer feedId);
	
	@Query("DELETE FROM SelectedFields s WHERE s.selectedFieldId=:selectedFieldId")
	void deleteSelected(@Param("selectedFieldId")Integer selectedField);
}
