package com.ust.hpsreport.repositorycustom;

public class SelectedFieldsRepoCustom {

	void updateSlectedByFieldName() {
		
	}
}
