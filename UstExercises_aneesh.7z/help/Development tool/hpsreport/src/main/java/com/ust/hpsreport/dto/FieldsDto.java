package com.ust.hpsreport.dto;

public class FieldsDto {

	private int availableFieldId;
	private String fieldName;
	private int feedTypeId;
	private String description;

	public int getAvailableFieldId() {
		return availableFieldId;
	}

	public void setAvailableFieldId(int availableFieldId) {
		this.availableFieldId = availableFieldId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public int getFeedTypeId() {
		return feedTypeId;
	}

	public void setFeedTypeId(int feedTypeId) {
		this.feedTypeId = feedTypeId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
