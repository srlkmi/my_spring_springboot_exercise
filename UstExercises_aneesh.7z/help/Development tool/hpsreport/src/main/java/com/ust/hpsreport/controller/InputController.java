package com.ust.hpsreport.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.hpsreport.dto.FeedDto;
import com.ust.hpsreport.dto.FieldsDto;
import com.ust.hpsreport.dto.RequestDTO;
import com.ust.hpsreport.dto.SelectedFieldsDTO;
import com.ust.hpsreport.service.HpsService;

@RestController
@CrossOrigin(origins = "*")
public class InputController {

	@Autowired
	HpsService hpsService;

	@RequestMapping(value = "/getallfeedtypes", method = RequestMethod.GET)
	public Object getAllFeedTypes() {

		List<FeedDto> feedList = hpsService.getAllFeedTypes();
		return feedList;
	}

	@RequestMapping(value = "/getavailablefields", method = RequestMethod.GET)
	public Object getAllAvailableFields(@RequestParam(value = "feedtype", required = true) Integer feedType) {

		List<FieldsDto> availableFieldList = hpsService.getAvailableFieldsByFeedType(feedType);
		return availableFieldList;
	}

	@RequestMapping(value = "/getselectedfields", method = RequestMethod.GET)
	public Object getAllSelectedFields(@RequestParam("feednameid") Integer feedNameId) {

		List<SelectedFieldsDTO> availableFieldList = hpsService.getSelectedFieldsByFeedName(feedNameId);
		return availableFieldList;
	}

	@RequestMapping(value = "/getallfeedname", method = RequestMethod.GET)
	public Object getAllFeedNames(@RequestParam("feedtype") Integer feedTypeId) {

		List<FeedDto> feedList = hpsService.getAllFeedNamesByFeedType(feedTypeId);
		return feedList;
	}

	@PostMapping(value = "/setFeed")
	public Object setFeedType(@RequestBody RequestDTO requestDTO) {

		return hpsService.setFeedName(requestDTO);

	}
	

}
