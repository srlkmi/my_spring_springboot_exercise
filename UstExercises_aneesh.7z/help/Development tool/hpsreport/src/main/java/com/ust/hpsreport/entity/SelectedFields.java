package com.ust.hpsreport.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(schema = "selected_fields")
public class SelectedFields implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ID")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer selectedFieldId;

	@Column(name = "AVAILABLE_FIELD_ID")
	private Integer availableFieldId;

	@Column(name = "FEED_NAME_ID")
	private Integer feedNameId;

	@Column(name = "ORDER_NUMBER")
	private Integer order;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FEED_NAME_ID", insertable = false, updatable = false)
	private FeedName feedName;

	@ManyToOne( fetch = FetchType.LAZY)
	@JoinColumn(name = "AVAILABLE_FIELD_ID", insertable = false, updatable = false)
	private AvailableFields availableFields;

	@Column(name = "isObsolete", columnDefinition = "Boolean default '0'")
	private Boolean isObsolete;

	public FeedName getFeedName() {
		return feedName;
	}

	public void setFeedName(FeedName feedName) {
		this.feedName = feedName;
	}

	public Integer getSelectedFieldId() {
		return selectedFieldId;
	}

	public void setSelectedFieldId(Integer selectedFieldId) {
		this.selectedFieldId = selectedFieldId;
	}

	public Integer getAvailableFieldId() {
		return availableFieldId;
	}

	public void setAvailableFieldId(Integer availableFieldId) {
		this.availableFieldId = availableFieldId;
	}

	public Integer getFeedNameId() {
		return feedNameId;
	}

	public void setFeedNameId(Integer feedNameId) {
		this.feedNameId = feedNameId;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public AvailableFields getAvailableFields() {
		return availableFields;
	}

	public void setAvailableFields(AvailableFields availableFields) {
		this.availableFields = availableFields;
	}

	public Boolean getIsObsolete() {
		return isObsolete;
	}

	public void setIsObsolete(Boolean isObsolete) {
		this.isObsolete = isObsolete;
	}

}
