package com.ust.SpringBootThymeleafViewTestProSecond;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThymeleafViewTestProSecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThymeleafViewTestProSecondApplication.class, args);
	}

}
