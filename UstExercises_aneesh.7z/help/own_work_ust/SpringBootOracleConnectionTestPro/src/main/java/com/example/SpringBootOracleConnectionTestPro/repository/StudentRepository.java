package com.example.SpringBootOracleConnectionTestPro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringBootOracleConnectionTestPro.model.StudentModel;

public interface StudentRepository extends JpaRepository<StudentModel, Integer>{

}
