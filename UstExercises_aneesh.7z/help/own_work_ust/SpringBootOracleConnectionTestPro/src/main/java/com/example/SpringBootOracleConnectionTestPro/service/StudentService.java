package com.example.SpringBootOracleConnectionTestPro.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringBootOracleConnectionTestPro.model.StudentModel;
import com.example.SpringBootOracleConnectionTestPro.repository.StudentRepository;
import antlr.collections.List;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;

	public void saveStudentData(StudentModel studentModel) {
		studentRepository.save(studentModel);
	}

	public StudentModel getStudentData(StudentModel studentModel) {

		return studentRepository.getOne(studentModel.getRollno());
	}

	public void updateStudentData(StudentModel studentModel) {
		studentRepository.save(studentModel);
	}

	public void deleteStudent(StudentModel studentModel) {
		studentRepository.deleteById(studentModel.getRollno());
	}

	public java.util.List<StudentModel> viewAllStudent() {
		return studentRepository.findAll(); 
	}

}
