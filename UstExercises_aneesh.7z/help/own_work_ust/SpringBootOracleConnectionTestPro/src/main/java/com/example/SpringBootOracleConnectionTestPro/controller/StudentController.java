package com.example.SpringBootOracleConnectionTestPro.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.SpringBootOracleConnectionTestPro.model.StudentModel;
import com.example.SpringBootOracleConnectionTestPro.service.StudentService;


@EnableAutoConfiguration
//@RestController
@Controller
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String register() {
		return "register";

	}

	@RequestMapping(value = "/registeraction", method = RequestMethod.POST)
	public String gotoNextPage(@ModelAttribute StudentModel studentModel) {
		studentService.saveStudentData(studentModel);
		return "../static/index";
	}
	
	@RequestMapping(value = "/view")
	public String gotoViewPage()
	{
		return "viewpage";
	}
	
	@RequestMapping(value = "/viewdetails")
	public ModelAndView  gotoViewDetails(@ModelAttribute StudentModel studentModel)
	{
		StudentModel smodel=studentService.getStudentData(studentModel);
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("smodel", smodel);
		modelAndView.setViewName("viewdetails");
		return modelAndView;
	}
	
	@RequestMapping(value = "/update")
	public String gotoUpdatePage()
	{
		return "updatepage";
	}
	
	@RequestMapping(value = "/updatedetails")
	public ModelAndView  gotoUpdateDetails(@ModelAttribute StudentModel studentModel)
	{
		StudentModel smodel=studentService.getStudentData(studentModel);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("smodel", smodel);
		modelAndView.setViewName("updatedetails");
		return modelAndView;
	}
	
	@RequestMapping(value = "/updateaction")
	public String updateStudentAction(@ModelAttribute StudentModel studentModel)
	{
		studentService.saveStudentData(studentModel);
		return "../static/index";
	}
	
	@RequestMapping(value = "/delete")
	public String gotoDeletePage()
	{
		return "deletepage";
	}
	
	@RequestMapping(value = "/deleteaction")
	public String gotoDeleteDetails(@ModelAttribute StudentModel studentModel)
	{
		studentService.deleteStudent(studentModel);
		return "../static/index";
	}
	
	@RequestMapping("/viewall")
	public String gotoViewAllDetailsPage(Model model)
	{
		List<StudentModel> smodel=studentService.viewAllStudent();
		//System.out.println(smodel);
		model.addAttribute("smodel",smodel);
		return "viewalldetails";
	}
	
	@RequestMapping("/back")
	public String gotoBack()
	{
		return "../static/index";
	}

}
