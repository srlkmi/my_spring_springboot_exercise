package com.ust.SpringTestSecondPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTestSecondProApplicationTests {

	@Test
	void contextLoads() {
	}

}
