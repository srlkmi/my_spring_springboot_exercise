package com.ust.SpringTestSecondPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTestSecondProApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTestSecondProApplication.class, args);
	}

}
