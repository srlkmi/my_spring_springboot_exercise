package com.example.SpringbootKafka;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.kafka.KafkaConstants;
import org.springframework.stereotype.Component;

//@Component
public class RouteToKafka extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("file:src/main/resources/static?noop=true")
		//from("file:src/main/resources/static?noop=true")
		//from("sql:select * from team")
        //.setBody(constant("Message from Camel")) // Message to send
        .setHeader(KafkaConstants.KEY, constant("filedetails")) // Key of the message
        .split().body().to("kafka:springboot-kafka-one?brokers=localhost:9092");
	}

}
