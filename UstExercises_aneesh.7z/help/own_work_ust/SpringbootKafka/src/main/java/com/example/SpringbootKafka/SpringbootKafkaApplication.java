package com.example.SpringbootKafka;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootKafkaApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringbootKafkaApplication.class, args);

//		RouteToKafka ka = new RouteToKafka();
//		CamelContext context = new DefaultCamelContext();
//		context.addRoutes(ka);
//		context.start();
//		Thread.sleep(10000);
//		context.stop();

	}

}
