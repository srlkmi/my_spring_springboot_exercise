package com.example.RetrieveDataUsingCamelFromDbTestPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetrieveDataUsingCamelFromDbTestProApplicationTests {

	@Test
	void contextLoads() {
	}

}
