package com.example.RetrieveDataUsingCamelFromDbTestPro.model;

import java.util.List;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.RetrieveDataUsingCamelFromDbTestPro.service.EmployeeService;

@Component
public class CamelRoute extends RouteBuilder {

	@Autowired
	EmployeeService employeeService;

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		List<EmployeeEntity> smodel = employeeService.viewAllStudent();
		for (EmployeeEntity employeeEntity : smodel) {
			System.out.println(employeeEntity.getId() + " " + employeeEntity.getName() + " " + employeeEntity.getSalary());
		}
		
		String topicName = "topic=db-camel-kafka";
		String kafkaServer = "kafka:localhost:9092";
		String zooKeeperHost = "zookeeperHost=localhost&zookeeperPort=2181";
		String serializerClass = "serializerClass=kafka.serializer.StringEncoder";

		String toKafka = new StringBuilder().append(kafkaServer).append("?").append(topicName).append("&")
				.append(zooKeeperHost).append("&").append(serializerClass).toString();
		
		from("file:C:\\Users\\144058\\Downloads\\RetrieveDataUsingCamelFromDbTestPro\\data?noop=true").split().tokenize("\n").to(toKafka);
	}

}
