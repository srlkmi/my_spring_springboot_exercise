package com.example.RetrieveDataUsingCamelFromDbTestPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrieveDataUsingCamelFromDbTestProApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetrieveDataUsingCamelFromDbTestProApplication.class, args);
	}

}
