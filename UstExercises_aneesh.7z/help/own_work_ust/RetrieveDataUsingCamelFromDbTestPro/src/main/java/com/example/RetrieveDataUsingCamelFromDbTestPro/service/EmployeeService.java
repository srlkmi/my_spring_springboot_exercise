package com.example.RetrieveDataUsingCamelFromDbTestPro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.RetrieveDataUsingCamelFromDbTestPro.model.EmployeeEntity;
import com.example.RetrieveDataUsingCamelFromDbTestPro.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public java.util.List<EmployeeEntity> viewAllStudent() {
		return employeeRepository.findAll();
	}
}
