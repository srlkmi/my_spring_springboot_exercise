package com.ust.spring.JdbcTemplateTutorial;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
	{
		try {
			
			/*
			 * Class.forName("oracle.jdbc.driver.OracleDriver");
			 * 
			 * //step2 create the connection object Connection
			 * con=DriverManager.getConnection(
			 * "jdbc:oracle:thin:@localhost:1521:xe","mydb","mydb");
			 * 
			 * //step3 create the statement object Statement stmt=con.createStatement();
			 * 
			 * stmt.execute("insert into employee values(105, 'Anu', 5000.00f)");
			 */
			
			
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
			//EmployeeDao employeeDao = (EmployeeDao) applicationContext.getBean("employee_dao_bean");

			//int status = employeeDao.saveEmployee(new Employee(105, "Anu", 5000.00f));
			//System.out.println(status);

			// int status=employeeDao.updateEmployee(new Employee(102,"Anil",10000.0f));
			// System.out.println(status);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("\nException : " + e);
		}

	}
}
