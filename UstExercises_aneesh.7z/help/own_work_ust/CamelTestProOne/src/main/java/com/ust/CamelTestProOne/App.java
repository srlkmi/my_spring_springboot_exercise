package com.ust.CamelTestProOne;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class App {
	public static void main(String[] args) throws Exception {
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() throws Exception {
				// TODO Auto-generated method stub
				from("file:D:\\Camelworkspace\\CamelTestProOne\\src\\main\\java\\data?noop=true")
						.to("file:D:\\Camelworkspace\\CamelTestProOne\\src\\main\\java\\dataout");
				from("file:D:\\Camelworkspace\\CamelTestProOne\\src\\main\\java\\dataout?noop=true").choice()
						.when(header("CamelFileName").endsWith(".xml"))
						.to("file:D:\\Camelworkspace\\CamelTestProOne\\src\\main\\java\\xmlfiles")
						.when(header("CamelFileName").endsWith(".txt"))
						.to("file:D:\\Camelworkspace\\CamelTestProOne\\src\\main\\java\\txtfiles");
			}
		});

		camelContext.start();
		Thread.sleep(10000);
		camelContext.stop();
	}
}
