package com.ust.spring.ConstructorInjectionExamples;

import java.util.Iterator;

public class Question 
{
	private int id;
	public String q_name;
	java.util.List<Answer> answers;
	
	public Question(int id, String q_name, java.util.List<Answer> answers) 
	{
		super();
		this.id = id;
		this.q_name = q_name;
		this.answers = answers;
	}
	
	public void show()
	{
		System.out.println(id);
		System.out.println(q_name);
		System.out.println("Answers are");
		
		Iterator<Answer> it=answers.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
}
