package com.ust.spring.ConstructorInjectionExamples;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Questionss 
{
	private int qid;
	private String qname;
	private Map<UserData, AnswerData> map;
	public Questionss(int qid, String qname, Map<UserData, AnswerData> map) 
	{
		super();
		this.qid = qid;
		this.qname = qname;
		this.map = map;
		
	}
	public void show()
	{
		System.out.println(qid);
		System.out.println(qname);
		System.out.println("Answers...");
		Set<Entry<UserData, AnswerData>> set=map.entrySet();
		Iterator<Entry<UserData, AnswerData>> itr=set.iterator();
		while(itr.hasNext())
		{
			Entry<UserData, AnswerData> entry=itr.next();
			UserData userData=entry.getKey();
			AnswerData answerData=entry.getValue();
			System.out.println(userData);
			System.out.println(answerData);
		}
	}
	
}
