package com.ust.spring.ConstructorInjectionExamples;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test 
{
	public static void main(String args[])
	{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//Employee employee=(Employee)applicationContext.getBean("employee_bean");
		//employee.show();
		
		/*
		 * Question question=(Question)applicationContext.getBean("question_bean");
		 * question.show();
		 */
		
		/*
		 * Question question=(Question)applicationContext.getBean("q_bean");
		 * question.show();
		 */
		
		/*
		 * Questions questions=(Questions)applicationContext.getBean("questions_id");
		 * questions.show();
		 */
		
		Questionss questions=(Questionss)applicationContext.getBean("Questionss_bean");
		questions.show();
	}
}
