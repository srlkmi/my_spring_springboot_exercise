package com.ust.spring.ConstructorInjectionExamples;

public class UserData 
{
	private int userid;
	private String username;
	private String useremail;
	public UserData(int userid, String username, String useremail) 
	{
		super();
		this.userid = userid;
		this.username = username;
		this.useremail = useremail;
	}
	public String toString()
	{
		return userid+" "+username+" "+useremail;
	}
}
