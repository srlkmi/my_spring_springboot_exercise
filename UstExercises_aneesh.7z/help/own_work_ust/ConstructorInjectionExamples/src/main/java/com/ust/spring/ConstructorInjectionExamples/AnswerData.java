package com.ust.spring.ConstructorInjectionExamples;

public class AnswerData 
{
	private int answerid;
	private String answer;
	private String answer_date;
	public AnswerData(int answerid, String answer, String answer_date) 
	{
		super();
		this.answerid = answerid;
		this.answer = answer;
		this.answer_date = answer_date;
		
	}
	public String toString()
	{
		return answerid+" "+answer+" "+answer_date;
	}
	
}
