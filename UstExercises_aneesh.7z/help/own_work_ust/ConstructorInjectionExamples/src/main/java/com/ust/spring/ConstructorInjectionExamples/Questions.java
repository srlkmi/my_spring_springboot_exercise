package com.ust.spring.ConstructorInjectionExamples;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Questions 
{
	private int id;
	private String name;
	private Map<String, String> map;
	public Questions(int id, String name, Map<String, String> map) 
	{
		super();
		this.id = id;
		this.name = name;
		this.map = map;
	}
	
	public void show()
	{
		System.out.println(id);
		System.out.println(name);
		System.out.println("Answers...");
		
		Set<Entry<String, String>> set=map.entrySet();
		Iterator<Entry<String, String>> itr=set.iterator();
		while(itr.hasNext())
		{
			Entry<String, String> entry=itr.next();
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}
	
}
