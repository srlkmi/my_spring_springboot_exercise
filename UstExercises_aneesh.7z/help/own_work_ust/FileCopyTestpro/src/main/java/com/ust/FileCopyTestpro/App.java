package com.ust.FileCopyTestpro;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {
	public static void main(String[] args) throws Exception {
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(new RouteBuilder() {
			@Override
			public void configure() {
				/*
				 * Logger logger=LoggerFactory.getLogger(App.class);
				 * logger.info("testing camel");
				 */
				//System.out.println("Hello");
				from("file:D:\\Camelworkspace\\FileCopyTestpro\\src\\main\\java\\inbox?noop=true").to("file:D:\\Camelworkspace\\FileCopyTestpro\\src\\main\\java\\outbox");
			}
		});
		camelContext.start();
		Thread.sleep(10000);
		camelContext.stop();
	}
}
