package com.example.FirstWorkTestPro;


import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.bindy.csv.BindyCsvDataFormat;
import org.apache.camel.spi.DataFormat;
import org.springframework.beans.factory.annotation.Autowired;

public class CreateSimpleRouter extends RouteBuilder{

	
	private EmployeePersister employeePersister;
	
	@Autowired
	public CreateSimpleRouter(EmployeePersister employeePersister) {
		this.employeePersister=employeePersister;
	}
	
	public CreateSimpleRouter() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void configure() throws Exception {
		DataFormat data = new BindyCsvDataFormat(com.example.FirstWorkTestPro.EmployeeDataBean.class);
		from("file:C:\\Users\\144058\\Downloads\\FirstWorkTestPro\\csvfile?noop=true")
		.unmarshal(data)
		.process(new Processor() {	
			@Override
			public void process(Exchange exchange) throws Exception {
				List<EmployeeDataBean> test = new ArrayList<EmployeeDataBean>();
				test = (List<EmployeeDataBean>) exchange.getIn().getBody();
				exchange.getIn().setBody(test);
			}
		})
		//.log(LoggingLevel.INFO, "*****${body}*******")
		//.to("bean:employeePersister?method=saveEmployee(*,${body})");
		.bean(EmployeePersister.class,"saveEmployee(*,${body})");
		}
	
}
