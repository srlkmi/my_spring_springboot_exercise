package com.example.FirstWorkTestPro;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstWorkTestProApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(FirstWorkTestProApplication.class, args);
		
		CreateSimpleRouter createSimpleRouter=new CreateSimpleRouter();
		CamelContext camelContext=new DefaultCamelContext();
		camelContext.addRoutes(createSimpleRouter);
		camelContext.start();
		Thread.sleep(10000);
		camelContext.stop();
		
	}

}
