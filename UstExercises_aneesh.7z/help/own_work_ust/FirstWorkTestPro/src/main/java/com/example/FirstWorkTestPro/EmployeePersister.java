package com.example.FirstWorkTestPro;

import java.util.List;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class EmployeePersister {
	
	/*
	 * @Autowired EmployeeBean employeeBean;
	 */
	
	/*
	 * @Autowired EmployeeService employeeService;
	 */
	
	public void saveEmployee(Exchange ex, List<EmployeeDataBean> li) {
		for(EmployeeDataBean emp: li)
		{
			//System.out.println(emp.getId()+" "+emp.getName());
			EmployeeBean employeeBean=new EmployeeBean();
			
			employeeBean.setId(emp.getId());
			employeeBean.setName(emp.getName());
			
			//System.out.println("EmployeePersister "+employeeBean.getId()+" "+employeeBean.getName());
			EmployeeService employeeService=new EmployeeService();
			employeeService.saveEmployeeData(employeeBean);
			//employeeService.saveEmployeeData();
			
			
		}
	}
}
