package com.example.FirstWorkTestPro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
	
	
	public void saveEmployeeData(EmployeeBean employeeBean) {
		//System.out.println("Hello service");
		System.out.println("EmployeeService "+employeeBean.getId()+" "+employeeBean.getName());
		/*
		 * EmployeeRepository employeeRepository=new EmployeeRepository();
		 * employeeRepository.save(employeeBean);
		 */
	}
}
