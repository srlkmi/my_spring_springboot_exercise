package com.example.FirstWorkTestPro;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.DataField;

@CsvRecord(separator = ",")
public class EmployeeDataBean {
	@DataField(pos = 1)
	private int id;
	@DataField(pos = 2)
	private String name;

	@Override
	public String toString() {
		return "GetEmployeeDataBean [id=" + id + ", name=" + name + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void getEmployeeDetails() {

	}
}
