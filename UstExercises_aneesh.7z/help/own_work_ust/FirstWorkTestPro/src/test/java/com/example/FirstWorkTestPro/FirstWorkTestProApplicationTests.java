package com.example.FirstWorkTestPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstWorkTestProApplicationTests {

	@Test
	void contextLoads() {
	}

}
