package com.ust.SpringBootTestMySql.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.SpringBootTestMySql.dto.FeedTypeDto;
import com.ust.SpringBootTestMySql.model.FeedTypeEntity;
import com.ust.SpringBootTestMySql.service.FeetypeService;

@RestController
public class FeedTypeController {
	
	@Autowired
	FeetypeService feedTypeService;
	
	@RequestMapping("/showfeedtype")
	public List<FeedTypeDto> showHome() {
		List<FeedTypeEntity> f1=new ArrayList<FeedTypeEntity>();
		List<FeedTypeDto> f2=new ArrayList<FeedTypeDto>();
		
		f1=feedTypeService.getFeedTypeDetails();
		for (FeedTypeEntity feedTypeEntity : f1) {
			//System.out.println(feedTypeEntity.getId()+" "+feedTypeEntity.getType_name());
			FeedTypeDto feedTypeDto=new FeedTypeDto();
			
			feedTypeDto.setId(feedTypeEntity.getId());
			feedTypeDto.setType_name(feedTypeEntity.getType_name());
			
			f2.add(feedTypeDto);
		}
		return f2;
	}
	@RequestMapping("/showavailablefields")
	public void showAvailableFields()
	{
		//return "Hello";
		
	}
}
