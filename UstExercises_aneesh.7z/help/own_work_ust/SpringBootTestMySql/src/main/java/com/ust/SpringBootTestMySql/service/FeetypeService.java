package com.ust.SpringBootTestMySql.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.SpringBootTestMySql.model.FeedTypeEntity;
import com.ust.SpringBootTestMySql.repository.AvailableFieldRepo;
import com.ust.SpringBootTestMySql.repository.FeedTypeRepo;

@Service
public class FeetypeService implements FeedTypeInterface {

	@Autowired
	FeedTypeRepo feedTypeRepo;
	
	@Autowired
	AvailableFieldRepo availableFieldRepo;

	public List<FeedTypeEntity> getFeedTypeDetails() {
		return feedTypeRepo.findAll();
	}

	public void getAllAvailableFields() {
		availableFieldRepo.findById(id);
	}
}
