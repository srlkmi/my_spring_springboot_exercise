package com.ust.SpringBootTestMySql.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "availablefields")
public class AvailableFieldsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String field_name;
	private int feed_type_id;
	private String description;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getField_name() {
		return field_name;
	}
	public void setField_name(String field_name) {
		this.field_name = field_name;
	}
	public int getFeed_type_id() {
		return feed_type_id;
	}
	public void setFeed_type_id(int feed_type_id) {
		this.feed_type_id = feed_type_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public AvailableFieldsEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
