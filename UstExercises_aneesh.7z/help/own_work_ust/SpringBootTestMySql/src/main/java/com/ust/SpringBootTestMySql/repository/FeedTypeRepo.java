package com.ust.SpringBootTestMySql.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.SpringBootTestMySql.model.FeedTypeEntity;

@Repository
public interface FeedTypeRepo extends JpaRepository<FeedTypeEntity, Integer>{

}
