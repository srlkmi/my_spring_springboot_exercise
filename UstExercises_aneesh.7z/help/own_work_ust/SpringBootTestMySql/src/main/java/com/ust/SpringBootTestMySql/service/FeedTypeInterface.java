package com.ust.SpringBootTestMySql.service;

public interface FeedTypeInterface {

}
