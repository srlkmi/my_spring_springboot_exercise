package com.ust.SpringBootTestMySql.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "feedtype")
public class FeedTypeEntity {
	//@Column(name = "AVAILABLE_FIELD_ID")
	//@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	//private Integer availableFieldId;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String type_name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType_name() {
		return type_name;
	}
	public void setType_name(String type_name) {
		this.type_name = type_name;
	}
	public FeedTypeEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
