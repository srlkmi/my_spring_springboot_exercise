package com.ust.SpringBootTestMySql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestMySqlApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootTestMySqlApplication.class, args);
	}
}
