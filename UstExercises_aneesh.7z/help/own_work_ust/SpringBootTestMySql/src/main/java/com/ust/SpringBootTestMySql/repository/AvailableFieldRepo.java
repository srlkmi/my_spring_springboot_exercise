package com.ust.SpringBootTestMySql.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.SpringBootTestMySql.model.AvailableFieldsEntity;

@Repository
public interface AvailableFieldRepo extends JpaRepository<AvailableFieldsEntity, Integer>{

}
