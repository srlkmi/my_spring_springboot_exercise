package com.ust.SpringBootCamelTestPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCamelTestProApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCamelTestProApplication.class, args);
	}

}
