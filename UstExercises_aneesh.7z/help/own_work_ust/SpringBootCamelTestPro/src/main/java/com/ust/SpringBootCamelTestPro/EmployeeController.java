package com.ust.SpringBootCamelTestPro;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmployeeController {
	@RequestMapping(value="/readdata", method=RequestMethod.POST)
	public void readEmployeeData(@ModelAttribute EmployeeBean employeeBean) {
		System.out.println(employeeBean.getId()+" "+employeeBean.getName());
	}
}
