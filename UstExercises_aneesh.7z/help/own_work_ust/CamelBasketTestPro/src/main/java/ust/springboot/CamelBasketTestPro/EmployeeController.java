package ust.springboot.CamelBasketTestPro;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeBean employeeBean;
	
	@RequestMapping("/readdata")
	public String readDataUsingBean()
	{
		/*
		 * employeeBean.setId(1); employeeBean.setName("Anu");
		 * 
		 * //ystem.out.println(employeeBean.getId()+" "+employeeBean.getName());
		 * 
		 */	
		return "Hello";
	}
}
