package com.example.SpringCamelTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCamelTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCamelTestApplication.class, args);
		System.out.println("Hello");
	}

}
