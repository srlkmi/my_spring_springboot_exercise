package com.example.SpringCamelTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCamelTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
