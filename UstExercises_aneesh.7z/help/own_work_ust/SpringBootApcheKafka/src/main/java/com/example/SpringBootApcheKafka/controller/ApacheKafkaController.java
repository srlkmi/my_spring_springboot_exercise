package com.example.SpringBootApcheKafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootApcheKafka.service.ApacheKafkaService;

@RestController
@RequestMapping(value = "/javainuse-kafka/")

public class ApacheKafkaController {
	@Autowired
	ApacheKafkaService apacheKafkaService;

	@GetMapping(value = "/producer")
	public String producer(@RequestParam("message") String message) {
		apacheKafkaService.send(message);

		return "Message sent to the Kafka Topic java_in_use_topic Successfully";
	}
}
