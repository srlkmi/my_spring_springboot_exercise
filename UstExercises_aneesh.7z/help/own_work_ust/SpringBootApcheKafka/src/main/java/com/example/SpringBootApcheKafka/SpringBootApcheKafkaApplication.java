package com.example.SpringBootApcheKafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApcheKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApcheKafkaApplication.class, args);
	}
}
