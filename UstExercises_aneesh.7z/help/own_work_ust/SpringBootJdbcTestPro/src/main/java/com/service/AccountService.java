package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.model.Account;
import com.repository.AccountDao;

@Service
public class AccountService {
	@Autowired
	AccountDao accountDao;

	public Account addAccount(Account account) {
		return this.accountDao.save(account);
	}
}
