package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.Account;
import com.service.AccountService;


@RestController
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	
	
	@RequestMapping("/")
	public String redirectTo() {
		return "index";
	}

	
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String addNewAccount(@RequestBody Account account) {
		//System.out.println(account);
		Account account2=accountService.addAccount(account);
		return "search";
	}
}
