package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

@Entity
@Table(name = "ACCOUNT_TABLE")
public class Account {
	@Id
	private Integer accountno;
	private String name;
	private Integer phone;

	public int getAccountno() {
		return accountno;
	}

	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	
	public Account(int accountno, String name, int phone) {
		this.accountno=accountno;
		this.name=name;
		this.phone=phone;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
