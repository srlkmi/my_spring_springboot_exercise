package com.ust.spring.FirstSpring;
public class Student 
{
	private String name1;
	private int rollno1;
	
	public String getName1() {
		return name1;
	}

	public int getRollno1() {
		return rollno1;
	}

	public void setRollno1(int rollno1) {
		this.rollno1 = rollno1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public void displayInfo()
	{
		System.out.println("Hello "+name1);
		System.out.println("Rollno "+rollno1);
	}
}
