package com.ust.spring.FirstSpring;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;

@Controller
public class Test 
{   
	public static void main(String args[])
	{
		/*
		 * Resource resource= new ClassPathResource("applicationContext.xml");
		 * BeanFactory beanFactory=new XmlBeanFactory(resource);
		 */
		
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("applicationContext.xml");
		/* Student student1=(Student) beanFactory.getBean("studentbean"); */
		Student student1=(Student) applicationContext.getBean("studentbean");
		student1.displayInfo();
	}
}
