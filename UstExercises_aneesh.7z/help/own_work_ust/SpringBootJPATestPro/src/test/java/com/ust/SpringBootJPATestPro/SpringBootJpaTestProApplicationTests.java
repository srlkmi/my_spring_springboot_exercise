package com.ust.SpringBootJPATestPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaTestProApplicationTests {

	@Test
	void contextLoads() {
	}

}
