package com.ust.SpringBootJPATestPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaTestProApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaTestProApplication.class, args);
	}

}
