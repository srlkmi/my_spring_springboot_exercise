package com.ust.spring.SpringJdbcExampleTwo;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDao 
{
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveData(Student student)
	{
		String query="insert into stud_data values('"+student.getId()+"','"+student.getName()+"','"+student.getPlace()+"'";
		return jdbcTemplate.update(query);
	}
}
