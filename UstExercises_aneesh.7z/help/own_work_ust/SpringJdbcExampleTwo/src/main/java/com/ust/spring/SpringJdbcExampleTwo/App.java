package com.ust.spring.SpringJdbcExampleTwo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("applicationContext.xml");
    	//System.out.println("0");
        
        StudentDao studentDao=(StudentDao)applicationContext.getBean("student_dao_bean");
        int ret=studentDao.saveData(new Student(101, "Anu", "Punalur"));
        System.out.println(ret);
    }
}
