package com.ust.spring.SetterInjectionExamples;

public class Employee 
{
	private int empid;
	private String name;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void show()
	{
		System.out.println("Employee id: "+empid+"\nEmployee Name: "+name);
	}
	
}
