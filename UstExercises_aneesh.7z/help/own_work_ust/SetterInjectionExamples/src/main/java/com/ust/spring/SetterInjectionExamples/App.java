package com.ust.spring.SetterInjectionExamples;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext aplApplicationContext=new ClassPathXmlApplicationContext("applicationContext.xml");
        Employee employee=(Employee)aplApplicationContext.getBean("employee_bean");
        employee.show();
    }
}
