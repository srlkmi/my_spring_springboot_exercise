package com.ust.spring.wiringExamples;

public class B 
{
	public B() 
	{
		super();
		System.out.println("B is created...");
	}
	
	public void print()
	{
		System.out.println("B Function...");
	}
}
