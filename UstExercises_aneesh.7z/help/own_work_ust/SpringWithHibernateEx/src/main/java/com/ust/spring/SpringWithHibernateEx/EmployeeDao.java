package com.ust.spring.SpringWithHibernateEx;

import org.springframework.orm.hibernate3.HibernateTemplate;

public class EmployeeDao {
	HibernateTemplate template;

	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	public void saveData(EmployeePersistant employeePersistant) {
		template.save(employeePersistant);
	}
}
