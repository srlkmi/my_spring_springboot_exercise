package com.ust.spring.SpringWithHibernateEx;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    		//Class.forName("org.apache.commons.dbcp.BasicDataSource");
    		
			/*
			 * ApplicationContext applicationContext=new
			 * ClassPathXmlApplicationContext("applicationContext.xml"); EmployeeDao
			 * employeeDao=(EmployeeDao)applicationContext.getBean("d");
			 */
    		
    		Resource r=new ClassPathResource("applicationContext.xml");  
    	    BeanFactory factory=new XmlBeanFactory(r);  
    	    EmployeeDao dao=(EmployeeDao)factory.getBean("d");
            
    	    dao.saveData(new EmployeePersistant(101, "Anu", "Punalur"));
            
    	
    }
}
