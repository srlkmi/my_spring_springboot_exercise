package com.example.ReadCsvDataStoreDbTestPro;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

//@Component
public class RetrieveDataFromDatabase extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("sql:select * from team").to("stream:out");
		/*
		 * from("direct:start").to("sql:select * from team").process(new Processor() {
		 * 
		 * @Override public void process(Exchange exchange) throws Exception { // TODO
		 * Auto-generated method stub System.out.println(exchange.getIn().getBody()); }
		 * });
		 */
	}
}
