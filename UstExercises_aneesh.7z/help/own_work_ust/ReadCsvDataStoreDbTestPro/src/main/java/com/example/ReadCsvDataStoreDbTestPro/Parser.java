package com.example.ReadCsvDataStoreDbTestPro;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.camel.builder.RouteBuilder;

import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;

import java.nio.charset.StandardCharsets;

import java.nio.file.Files;

import java.nio.file.Paths;

public class Parser {

	/*
	 * public static void main(String[] args) throws IOException {
	 * 
	 * ObjectMapper objectMapper = new XmlMapper(); // Reads from XML and converts
	 * to POJO Employees employees = objectMapper.readValue(
	 * StringUtils.toEncodedString(Files.readAllBytes(Paths.get(
	 * "C:\\Users\\144058\\Downloads\\ReadCsvDataStoreDbTestPro\\files\\employees.xml"
	 * )),StandardCharsets.UTF_8),Employees.class); System.out.println(employees);
	 * Object fieldSet = null; // Reads from POJO and converts to XML
	 * objectMapper.writeValue(new File(
	 * "C:\\Users\\144058\\Downloads\\ReadCsvDataStoreDbTestPro\\files\\employees.xml"
	 * ), fieldSet);
	 * 
	 * }
	 * 
	 * @Override public void configure() throws Exception { //Test XML Data read
	 * //System.out.println("Hello"); }
	 */
}