package com.example.ReadCsvDataStoreDbTestPro;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.springframework.stereotype.Component;

@Component
public class ReadDataFromFile extends RouteBuilder {
	@Override
	public void configure() throws Exception {
		
		//CSV Data format
		
		
		/*
		 * DataFormat dataFormat = new BindyCsvDataFormat(CsvDataRead.class); from(
		 * "file:C:\\Users\\144058\\Downloads\\ReadCsvDataStoreDbTestPro\\files?noop=true"
		 * ).unmarshal(dataFormat) .split(body()).
		 * to("sql:insert into team(id,name) values(:#${body.id},:#${body.name})");
		 */
		 
		 

		// XML Data Format
		//JacksonXMLDataFormat xmlDataFormat = new JacksonXMLDataFormat(ListXmlEmployee.class);
		//JacksonXMLDataFormat format = new ListJacksonXMLDataFormat(ListXmlEmployee.class);
		/*
		 * format.useList(); format.setUnmarshalType();
		 */
		
		
		/*
		 * from("file:src/main/resources/xmldata?noop=true")
		 * .unmarshal(format).split(body()).log("${body.getEmpName}");
		 */
		  
		  /*.process(new Processor() {
			
			@Override
			public void process(Exchange exchange) throws Exception {
				// TODO Auto-generated method stub
				System.out.println(exchange.getIn().getBody().toString());
			}
		});*/
		 
				//.to("sql:insert into xmldatatable(empid,empname) values(:#${body.empId},:#${body.empName})");
				//.to("stream:out");
		
				//.unmarshal().jaxb(XmlDataRead.class.getPackage().getName().toString()).split(body()).log("${body.empId}");
		
		
		JAXBContext jaxbContext = JAXBContext.newInstance(XmlDataRead.class);
		JaxbDataFormat jaxbDataFormat = new JaxbDataFormat(jaxbContext);
		from("file:src/main/resources/xmldata?noop=true").unmarshal(jaxbDataFormat)
		.log("processing person: ${body.getName}")
		.split().simple("${body.hobbies}")
		// Process each hobby separately.
		.log("....hobby: ${body.getName}")
		.end();
		
	}
}
