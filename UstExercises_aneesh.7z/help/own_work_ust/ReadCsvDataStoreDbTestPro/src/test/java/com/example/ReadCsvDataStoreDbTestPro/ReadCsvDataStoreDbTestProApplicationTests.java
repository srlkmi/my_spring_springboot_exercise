package com.example.ReadCsvDataStoreDbTestPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadCsvDataStoreDbTestProApplicationTests {

	@Test
	void contextLoads() {
	}

}
