package com.ust.ApacheKafka;

public class MyBean {
	public String myMethod() {
		return "Hello Hai Test";
	}
}
