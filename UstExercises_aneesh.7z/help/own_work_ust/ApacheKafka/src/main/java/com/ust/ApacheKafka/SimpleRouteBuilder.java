package com.ust.ApacheKafka;

import org.apache.camel.builder.RouteBuilder;

public class SimpleRouteBuilder extends RouteBuilder {
	@Override
	public void configure() throws Exception {

		String s="Anu";
		String topicName = "topic=message-send-kafka";
		String kafkaServer = "kafka:localhost:9092";
		String zooKeeperHost = "zookeeperHost=localhost&zookeeperPort=2181";
		String serializerClass = "serializerClass=kafka.serializer.StringEncoder";

		String toKafka = new StringBuilder().append(kafkaServer).append("?").append(topicName).append("&")
				.append(zooKeeperHost).append("&").append(serializerClass).toString();

		
		//from("file:D:\\Springbootworkspaceone\\ApacheKafka\\src\\main\\java\\com\\ust\\ApacheKafka\\files?noop=true").split().tokenize("\n").to(toKafka);
		//from("file:files/?noop=true").split().tokenize("\n").to(toKafka);
		/*
		 * Date future = new Date(new Date().getTime() + 1000); SimpleDateFormat sdf =
		 * new SimpleDateFormat("dd-MM-yyyy HH:mm:ss"); String time =
		 * sdf.format(future); System.out.println(time); fromF(
		 * ("timer://dbQueryTimer?period=500000&time=%s&pattern=dd-MM-yyyy HH:mm:ss"),
		 * time)
		 */
		
		 from("file:D:\\Springbootworkspaceone\\ApacheKafka\\src\\main\\java\\com\\ust\\ApacheKafka\\files?noop=true")
         .choice()
             .when(simple("${header.foo} == 'bar'"))
                 .to("direct:b")
             .when(simple("${header.foo} == 'cheese'"))
                 .to("direct:c")
             .otherwise()
                 .to("direct:d");

		
		//from("direct:App").bean(new MyBean(), "myMethod").split().tokenize("a").to(toKafka);

		//from("direct:SimpleRouteBuilder").setBody(simple("Anu")).to(toKafka);
		
	}
}
