package com.example.SpringBootOracleJdbcTestPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOracleJdbcTestProApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOracleJdbcTestProApplication.class, args);
		System.out.println("Hai oracle...");
	}

}
