package com.example.SpringBootOracleJdbcTestPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOracleJdbcTestProApplicationTests {

	@Test
	void contextLoads() {
	}

}
