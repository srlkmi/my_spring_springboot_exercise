package controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import dao.Account;
import dao.AccountDao;

@Controller
public class AccountController {
	@Autowired
	AccountDao daobean;

	@RequestMapping("/accountform")
	public String showform() {
		// System.out.println("0");
		// model.addAttribute("command",new Account());
		return "addaccountform";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveData(@ModelAttribute("accnt") Account account) throws SQLException {
		int status = daobean.save(account);
		return "redirect:/viewmap";
	}

	@RequestMapping("viewmap")
	public String showData(Model model) {
		List<Account> list=daobean.getAccountHolders();
		model.addAttribute("account_list",list);
		return "accountviewpage";
	}
}
