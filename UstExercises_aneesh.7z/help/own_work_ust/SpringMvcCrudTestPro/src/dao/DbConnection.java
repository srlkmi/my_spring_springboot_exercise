package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class DbConnection {
	Connection con;
	Statement stmt;
	PreparedStatement stmt1;
	public DbConnection() {
		// TODO Auto-generated constructor stub
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","mydb","mydb");  
			  
			//step3 create the statement object  
			stmt=con.createStatement(); 
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}

 