package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class AccountDao {
	
	// Database connection using calss
	@Autowired
	DbConnection dbConnection;
	
	/*
	 * @Autowired SpringJdbcConfig springJdbcConfig;
	 * 
	 * DataSource dataSource=SpringJdbcConfig.oracleDataSource();
	 * 
	 * JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
	 */

	public int save(Account account) {
		int re = 0;
		try {
			/*
			 * System.out.println(account.getId()+" "+account.getName()+" "+account.
			 * getSalary()+" "+account.getAccno()); String query =
			 * "insert into Account(id,accno,name,salary) values('" + account.getId() +
			 * "','"+ account.getAccno() + "','" + account.getName() + "','" +
			 * account.getSalary() + "'"; re= dbConnection.stmt.executeUpdate(query);
			 */
			// return jdbcTemplate.update(query);

			String insert = "INSERT INTO Account (id,accno,name,salary) " + " VALUES (?,?,?,?)";
			dbConnection.stmt1 = dbConnection.con.prepareStatement(insert);
			dbConnection.stmt1.setInt(1, account.getId());
			dbConnection.stmt1.setString(2, account.getAccno());
			dbConnection.stmt1.setString(3, account.getName());
			dbConnection.stmt1.setFloat(4, account.getSalary());

			re = dbConnection.stmt1.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return re;
	}

	public List<Account> getAccountHolders() {
		List<Account> li = new ArrayList<Account>();
		List<String> li1=new ArrayList<String>();
		try {
			String query = "select * from account";
			ResultSet rs = dbConnection.stmt.executeQuery(query);
			while (rs.next()) {
				Account account = new Account();
				account.setName(rs.getString(3));
				System.out.println(rs.getString(3));
				
				/*
				 * account.setAccno(rs.getString(2)); account.setName(rs.getString(3));
				 * account.setSalary(rs.getFloat(4));
				 */

				li.add(account);
				li1.add("Hello");
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Retrive exception " + e);
		}
		System.out.println("List :" + li.toString());
		System.out.println("List1 :" + li1);
		return li;
	}
}
