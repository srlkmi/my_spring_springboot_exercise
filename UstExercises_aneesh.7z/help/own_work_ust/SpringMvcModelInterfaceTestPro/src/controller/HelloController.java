package controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {
	@RequestMapping("/hello")

	/* public String display(HttpServletRequest request, Model model) { */
	public String display(@RequestParam("name")String name,@RequestParam("pass")String password,Model model)
	{
		if(password.equalsIgnoreCase("admin"))
		{
			String msg="Hello "+name;
			model.addAttribute("message",msg);
			return "viewpage";
		}
		else
		{
			String msg="Hello "+name+" Sorry username/ Password error!";
			model.addAttribute("message",msg);
			return "errorpage";
		}
	}
}
