package com.controller;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_TABLE")
public class Model_Bean {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer ID;
	private String NAME;
	private String UROLE;

	public Model_Bean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Model_Bean(Integer iD, String nAME, String uROLE) {
		super();
		ID = iD;
		NAME = nAME;
		UROLE = uROLE;
	}

	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getUROLE() {
		return UROLE;
	}

	public void setUROLE(String uROLE) {
		UROLE = uROLE;
	}

}
