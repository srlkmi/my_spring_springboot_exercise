package com.controller;
import org.springframework.data.repository.CrudRepository;

public interface DaoRepository extends CrudRepository<Model_Bean, Integer> {

}
