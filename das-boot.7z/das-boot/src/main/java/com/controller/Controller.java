package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	@Autowired
	Services userservice;
	
	 @RequestMapping(value = "/adduser", method = RequestMethod.POST)
     @ResponseBody()
     public Model_Bean addNewUser(@ModelAttribute Model_Bean model) {
		 //System.out.println(model.getID()+" "+model.getNAME()+" "+model.getUROLE());
         return this.userservice.addUser(model);
     }
	 
	  @RequestMapping(value = "/all")
	     public List<Model_Bean> getAllUsers() {
	    	 
	         return userservice.getAll();
	     }
	  @RequestMapping(value="/del/{id}", method=RequestMethod.DELETE)
	  public void deleteuser(@PathVariable Integer id) {  
		  //System.out.println(model.getID()+" "+model.getNAME()+" "+model.getUROLE());
	      userservice.deluser(id);
	     
	     }
	  @RequestMapping(value="/updateuser/{id}", method=RequestMethod.PUT)
	  public Model_Bean updateuser(@PathVariable Integer id, Model_Bean model) {  
		System.out.println(model.getID()+" "+model.getNAME()+" "+model.getUROLE());
	     return userservice.updateUser(id,model);
	     
	     }
	 
}
