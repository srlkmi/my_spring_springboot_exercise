package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class Services {

	@Autowired
	DaoRepository Dao;
	
	public Model_Bean addUser(Model_Bean user) {
		 return this.Dao.save(user);
	}
	
	 public List<Model_Bean> getAll() {
         return (List<Model_Bean>) this.Dao.findAll();
     }
	
	 public void deluser(Integer id) {
	  this.Dao.deleteById(id);
	  
	 }
	 
	 public Model_Bean updateUser(Integer id,Model_Bean user) {
		 user.getID();	
		 user.getNAME();
		 user.getUROLE();
		 
		 return this.Dao.save(user);
	}
}
