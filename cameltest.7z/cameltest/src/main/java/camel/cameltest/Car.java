package camel.cameltest;

public class Car {

	public void car() {
		System.out.println("driving");
	}
}
