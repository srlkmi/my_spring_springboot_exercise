package camel.cameltest;

public class Bike {
	public void bike() {
		System.out.println("riding");
	}
}
