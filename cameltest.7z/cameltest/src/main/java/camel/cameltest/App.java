package camel.cameltest;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main(String args[]) throws Exception {
		
//		Car c= new Car();
//		c.car();
		CamelContext context = new DefaultCamelContext();
		context.addRoutes(new RouteBuilder() {
		public void configure() {
		from("file:datain/in?noop=true")
		.to("file:dataout/out");
//		from("file:data/inbox")
//		.filter().xpath("/order[not(@test)]")
//		.to("jms:queue:order");
		}
		});
		context.start();
		Thread.sleep(10000);
		context.stop();
		}
 
}
