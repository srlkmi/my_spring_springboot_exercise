package com.dbcamelkafkaboot.dbcamelkafkaboot.dbtokafka;

public class DbtoKafka {

}
