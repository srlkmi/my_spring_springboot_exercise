package com.dbcamelkafkaboot.dbcamelkafkaboot.xmltodb;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jacksonxml.JacksonXMLDataFormat;
import org.apache.camel.dataformat.bindy.csv.BindyCsvDataFormat;
import org.apache.camel.model.dataformat.JaxbDataFormat;
import org.apache.camel.spi.DataFormat;
import org.springframework.stereotype.Component;
@Component
public class XmltoDb extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		/*
		 * System.out.println("xml....");
		 * from("file:src/main/resources/static?noop=true") //
		 * .split(xpath("//order[@product='soaps']/items/item/Brand/text()"))
		 * .unmarshal().jacksonxml() .log("${body}")
		 * 
		 * .to("sql:INSERT INTO items (brand) VALUES (:#${body.order.items.item.Brand})"
		 * ) .log(".........inserted to db...");
		 */
		JacksonXMLDataFormat format = new JacksonXMLDataFormat(Item.class);
		from("file:src/main/resources/static?noop=true")
		.unmarshal(format)
		.split(body())
		.log("${body}")
		.to("sql:INSERT INTO ITEM (id,brand,type,price) VALUES (:#${body.id},:#${body.brand},:#${body.type},:#${body.price})");
		
	}

}
