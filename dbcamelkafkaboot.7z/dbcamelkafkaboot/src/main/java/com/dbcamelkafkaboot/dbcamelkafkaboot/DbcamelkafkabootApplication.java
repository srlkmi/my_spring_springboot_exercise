package com.dbcamelkafkaboot.dbcamelkafkaboot;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.dbcamelkafkaboot.dbcamelkafkaboot.xmltodb.XmltoDb;

@SpringBootApplication
public class DbcamelkafkabootApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(DbcamelkafkabootApplication.class, args);
		/*
		 * CamelContext context = new DefaultCamelContext(); XmltoDb xdb = new
		 * XmltoDb(); context.addRoutes(xdb); context.start(); Thread.sleep(10000);
		 * context.stop();
		 */
	}

}
