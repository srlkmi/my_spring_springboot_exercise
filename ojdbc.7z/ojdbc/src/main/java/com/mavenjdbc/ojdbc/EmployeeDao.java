package com.mavenjdbc.ojdbc;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}  
	public int saveEmployee(Employee e) {
		 String query="insert into EMP_DETAILS values('"+e.getId()+"','"+e.getName()+"','"+e.getRole()+"')";  
		return jdbcTemplate.update(query);
		 
	}
	public int deleteEmployee(Employee e){  
	    String query="delete from EMP_DETAILS where id='"+e.getId()+"' ";  
	    return jdbcTemplate.update(query);  
	}  
}
