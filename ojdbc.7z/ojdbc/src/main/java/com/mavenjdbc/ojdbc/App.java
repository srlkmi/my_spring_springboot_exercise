package com.mavenjdbc.ojdbc;

import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("appContext.xml");  
        
        EmployeeDao dao=(EmployeeDao)ctx.getBean("edao");  
        int status=dao.saveEmployee(new Employee(3,"Amit","developer"));  
        System.out.println(status);  
    }
}
