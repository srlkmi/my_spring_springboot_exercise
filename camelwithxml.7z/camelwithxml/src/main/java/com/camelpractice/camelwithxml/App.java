package com.camelpractice.camelwithxml;

import java.io.FileInputStream;
import java.io.InputStream;
import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws Exception {
		CamelContext context = new DefaultCamelContext();
		try {
			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {

//*************** route to csv file ***********************

					/*
					 * from("direct:App")
					 * .marshal().csv().to("file:src/main/resources/order?fileName=test1.csv")
					 * .to("stream:out");
					 */
					
//***************** xml split data **********************
					from("direct:App").split(xpath("//order[@product='soaps']/items")).to("stream:out");

				}
			});
			context.start();
			ProducerTemplate orderProducerTemplate = context.createProducerTemplate();
			InputStream orderInputStream = new FileInputStream(
					ClassLoader.getSystemClassLoader().getResource("order.xml").getFile());
			orderProducerTemplate.sendBody("direct:App", orderInputStream);
		} finally {
			context.stop();
		}
	}
}
